package com.flight.booking.service.impl;

import com.flight.booking.domain.User;
import com.flight.booking.exceptions.UnAuthorizedException;
import com.flight.booking.service.AuthenticationService;
import com.flight.booking.service.UserService;

public class AuthenticationServiceImpl implements AuthenticationService {

    private final UserService userService;

    public AuthenticationServiceImpl(UserService userService) {
        this.userService = userService;
    }

    @Override
    public User authenticateUser(String username, String password) {
        User user = userService.findByUserName(username);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        throw new UnAuthorizedException("Wrong credentials");
    }

}
