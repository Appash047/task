package com.flight.booking;

import com.flight.booking.domain.Flight;
import com.flight.booking.domain.User;
import com.flight.booking.enums.FlightType;
import com.flight.booking.exceptions.SeatsNotAvailableException;
import com.flight.booking.exceptions.UnAuthorizedException;
import com.flight.booking.service.AuthenticationService;
import com.flight.booking.service.FlightBookingService;
import com.flight.booking.service.UserService;
import com.flight.booking.service.impl.AuthenticationServiceImpl;
import com.flight.booking.service.impl.FlightBookingServiceImpl;
import com.flight.booking.service.impl.UserServiceImpl;
import com.flight.booking.utility.FileUtility;

import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;


public class FlightBooking {

    public static void main(String[] args) throws FileNotFoundException {
        UserService userService = new UserServiceImpl();
        AuthenticationService authenticationService = new AuthenticationServiceImpl(userService);
        FlightBookingService flightBookingService = new FlightBookingServiceImpl();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter username: ");
        String username = scanner.next();
        System.out.print("Please enter password: ");
        String password = scanner.next();
        try {
            User user = authenticationService.authenticateUser(username, password);
            if (user != null) {
                System.out.print("Please select flightType option:: ");
                Arrays.stream(FlightType.values()).forEach(System.out::println);
                try {
                    FlightType flightType = FlightType.valueOf(scanner.next());
                    System.out.println("Flights with flight type unsorted");
                    List<Flight> flightsByFlightType = flightBookingService.findByFlightType(flightType);
                    flightsByFlightType.forEach(System.out::println);
                    System.out.println("Flights with flight type sorted by fare");
                    List<Flight> sortedFlights = flightBookingService.sortByJourneyTimeAndFare(flightsByFlightType);
                    System.out.println("Choose any flight to book");
                    for (int i = 1; i <= sortedFlights.size(); i++) {
                        System.out.println(i + ". " + sortedFlights.get(i - 1));
                    }
                    int chosenFlight = scanner.nextInt();
                    try {
                        user.getReservedFlights().add(flightBookingService.reserveSeat(sortedFlights.get(chosenFlight - 1)));
                        System.out.println(user.getName() + " reserved seat in flights " + user.getReservedFlights());
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    System.out.println("Choose another flight to book");
                    int choseAnotherFlight = scanner.nextInt();
                    System.out.println("Choose number of seats required");
                    int noOfSeatsRequired = scanner.nextInt();
                    try {
                        user.getReservedFlights().add(flightBookingService.reserveSeat(sortedFlights.get(choseAnotherFlight - 1), noOfSeatsRequired));
                        System.out.println(user.getName() + " reserved seats in flights " + user.getReservedFlights());
                    } catch (SeatsNotAvailableException e) {
                        System.out.println(e.getMessage());
                    }
                } catch (IllegalArgumentException e) {
                    System.out.println("Flight type not found, please enter from the specified list");
                }
            }
        } catch (UnAuthorizedException e) {
            System.out.println(e.getMessage());
        }
    }

}
