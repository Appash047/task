package com.flight.booking.service.impl;

import com.flight.booking.domain.Flight;
import com.flight.booking.enums.FlightType;
import com.flight.booking.exceptions.SeatsNotAvailableException;
import com.flight.booking.service.FlightBookingService;
import com.flight.booking.utility.FileUtility;

import java.io.FileNotFoundException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class FlightBookingServiceImpl implements FlightBookingService {

    @Override
    public List<Flight> findAll() {
        List<Flight> flights = Collections.emptyList();
        try {
            flights = FileUtility.loadFlights();
        } catch (FileNotFoundException e) {
            System.out.println("File not available!");
        }
        return flights;
    }

    @Override
    public List<Flight> findByFlightType(FlightType flightType) {
        return findAll().stream().filter(flight -> flight.getFlightType().equals(flightType)).collect(Collectors.toList());
    }

    @Override
    public List<Flight> sortByTotalFare(List<Flight> flights) {
        Collections.sort(flights, Comparator.comparing(flight -> Integer.valueOf(flight.getFare())));
        return flights;
    }

    @Override
    public Flight reserveSeat(Flight flight) {

        return reserveSeat(flight, 1);
    }

    @Override
    public Flight reserveSeat(Flight flight, int numberOfSeatsRequired) {
        if (numberOfSeatsRequired < 0) {
            throw new IllegalArgumentException();
        }
        int noOfSeatsAvailable = flight.getNumberOfAvailableSeats();
        if (noOfSeatsAvailable > numberOfSeatsRequired) {
            flight.setNumberOfAvailableSeats(noOfSeatsAvailable - numberOfSeatsRequired);
        } else {
            throw new SeatsNotAvailableException("Have only " + noOfSeatsAvailable + " seats available");
        }
        return flight;
    }

    @Override
    public List<Flight> sortByJourneyTimeAndFare(List<Flight> flights) {

        Collections.sort(flights, (o1, o2) -> {
            if(o1.getJourneyTime()>o2.getJourneyTime()){
                return +1;
            }else if(o1.getJourneyTime()<o2.getJourneyTime()){
                return -1;
            }else {
                Integer fare1=o1.getFare();
                Integer fare2=o2.getFare();
                return fare1.compareTo(fare2);
            }
        });
        return flights;
    };
}
