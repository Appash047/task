package com.flight.booking.utility;

import com.flight.booking.domain.Flight;
import com.flight.booking.domain.User;
import com.flight.booking.enums.FlightType;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class FileUtility {

    public static Set<User> loadUsers() throws FileNotFoundException {
        Set<User> users = new HashSet<>();
        File file = new File("C:\\Users\\Abhimanyu\\Documents\\Workspace\\flight-booking\\src\\main\\resources\\users.txt");
        Scanner scanner = new Scanner(file);
        while (scanner.hasNext()) {
            String[] line = scanner.next().split(",");
            users.add(new User(line[0], line[1], line[2]));
        }
        return users;
    }

    public static List<Flight> loadFlights() throws FileNotFoundException {
        List<Flight> flights = new ArrayList<>();
        File file = new File("C:\\Users\\Abhimanyu\\Documents\\Workspace\\flight-booking\\src\\main\\resources\\flights.txt");
        Scanner scanner = new Scanner(file);
        while (scanner.hasNext()) {
            String[] line = scanner.next().split(",");
            flights.add(new Flight(line[0], line[1], Integer.valueOf(line[2]), Integer.valueOf(line[3]),
                    Integer.valueOf(line[4]), FlightType.valueOf(line[5])));
        }
        return flights;
    }
}
