package com.flight.booking.enums;

public enum FlightType {

    DOMESTIC, INTERNATIONAL

}
