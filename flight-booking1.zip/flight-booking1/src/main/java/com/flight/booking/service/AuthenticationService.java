package com.flight.booking.service;

import com.flight.booking.domain.User;

public interface AuthenticationService {

    User authenticateUser(String username, String password);

}
