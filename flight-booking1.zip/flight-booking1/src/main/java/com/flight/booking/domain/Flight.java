package com.flight.booking.domain;

import com.flight.booking.enums.FlightType;

public class Flight {

    private String flightNumber;

    private String airlineName;

    private String origin;

    private String destination;

    private int numberOfAvailableSeats;

    private int journeyTime;

    private int fare;

    private FlightType flightType;

    public Flight(String flightNumber, String airlineName, int numberOfAvailableSeats, int journeyTime, int fare, FlightType flightType) {
        this.flightNumber = flightNumber;
        this.airlineName = airlineName;
        this.numberOfAvailableSeats = numberOfAvailableSeats;
        this.journeyTime = journeyTime;
        this.fare = fare;
        this.flightType = flightType;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public int getNumberOfAvailableSeats() {
        return numberOfAvailableSeats;
    }

    public void setNumberOfAvailableSeats(int numberOfAvailableSeats) {
        this.numberOfAvailableSeats = numberOfAvailableSeats;
    }

    public int getJourneyTime() {
        return journeyTime;
    }

    public void setJourneyTime(int journeyTime) {
        this.journeyTime = journeyTime;
    }

    public int getFare() {
        return fare;
    }

    public void setFare(int fare) {
        this.fare = fare;
    }

    public FlightType getFlightType() {
        return flightType;
    }

    public void setFlightType(FlightType flightType) {
        this.flightType = flightType;
    }

    public String getAirlineName() {
        return airlineName;
    }

    public void setAirlineName(String airlineName) {
        this.airlineName = airlineName;
    }

    @Override
    public String toString() {
        return "Flight{" +
                "flightNumber='" + flightNumber + '\'' +
                ", airlineName='" + airlineName + '\'' +
                ", origin='" + origin + '\'' +
                ", destination='" + destination + '\'' +
                ", numberOfAvailableSeats=" + numberOfAvailableSeats +
                ", journeyTime=" + journeyTime +
                ", fare=" + fare +
                ", flightType=" + flightType +
                '}';
    }
}
