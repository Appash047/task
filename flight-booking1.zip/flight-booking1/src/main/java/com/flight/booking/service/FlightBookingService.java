package com.flight.booking.service;

import com.flight.booking.domain.Flight;
import com.flight.booking.domain.User;
import com.flight.booking.enums.FlightType;

import java.io.FileNotFoundException;
import java.util.List;

public interface FlightBookingService {

    List<Flight> findAll() throws FileNotFoundException;

    List<Flight> findByFlightType(FlightType flightType);

    List<Flight> sortByTotalFare(List<Flight> flights);

    Flight reserveSeat(Flight flight);

    Flight reserveSeat(Flight flight, int numberOfSeatsRequired);

    List<Flight> sortByJourneyTimeAndFare(List<Flight> flights);

}
