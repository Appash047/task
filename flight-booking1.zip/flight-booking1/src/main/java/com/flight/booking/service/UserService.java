package com.flight.booking.service;

import com.flight.booking.domain.User;

import java.io.FileNotFoundException;
import java.util.Set;

public interface UserService {

    Set<User> findAll() throws FileNotFoundException;

    User findByUserName(String username);

}
