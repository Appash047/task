package com.flight.booking.service.impl;

import com.flight.booking.domain.User;
import com.flight.booking.service.UserService;
import com.flight.booking.utility.FileUtility;

import java.io.FileNotFoundException;
import java.util.Set;

public class UserServiceImpl implements UserService {

    @Override
    public Set<User> findAll() throws FileNotFoundException {
        return FileUtility.loadUsers();
    }

    @Override
    public User findByUserName(String username) {
        User userToFind = null;
        try {
            for (User user: findAll()) {
                if (user.getUsername().equals(username)) {
                    userToFind = user;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
        return userToFind;
    }

}
