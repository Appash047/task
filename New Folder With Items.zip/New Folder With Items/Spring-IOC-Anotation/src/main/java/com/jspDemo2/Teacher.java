package com.jspDemo2;

import org.springframework.beans.factory.annotation.Value;

public class Teacher {

	@Value("1")
	int id;
	@Value("appi")
	String name;
	@Value("2000.00")
	double sal;

//	public Teacher(int id, String name, double sal) {
//		super();
//		this.id = id;
//		this.name = name;
//		this.sal = sal;
//	}

//	public void setId(int id) {
//		this.id = id;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}
//
//	public void setSal(double sal) {
//		this.sal = sal;
//	}

	public void display() {
		System.out.println("Teacher id : " + id);
		System.out.println("Teacher name : " + name);
		System.out.println("Teacher salary : " + sal);
	}
}
