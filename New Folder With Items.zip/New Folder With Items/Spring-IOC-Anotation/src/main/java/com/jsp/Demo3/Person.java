package com.jsp.Demo3;

import org.springframework.stereotype.Component;

@Component
public class Person {

	
	public void aadharNumber() {
		System.out.println("121223234455");
	}
}
