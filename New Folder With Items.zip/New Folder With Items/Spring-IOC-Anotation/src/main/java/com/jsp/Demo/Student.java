package com.jsp.Demo;

import org.springframework.stereotype.Component;

@Component
public class Student {

	void run() {
		System.out.println("Hi every one");
	}

}
