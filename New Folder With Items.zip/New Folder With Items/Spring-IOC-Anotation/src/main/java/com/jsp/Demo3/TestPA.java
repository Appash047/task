package com.jsp.Demo3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestPA {

	public static void main(String[] args) {

		ApplicationContext applicationContext=new AnnotationConfigApplicationContext(Configue.class);
		Aadhar aadhar=(Aadhar) applicationContext.getBean("aadhar");
		aadhar.test();
	}

}
