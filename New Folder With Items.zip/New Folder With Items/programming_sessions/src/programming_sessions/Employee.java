package programming_sessions;


public class Employee {
	
	String name;
	String empId;
	int basicSalary;
	int da,pf,hra,grossSalary,netSalary;
	
	public void details(String name,String empId,int basicSalary)
	{
		this.name=name;
		this.empId=empId;
		this.basicSalary=basicSalary;
	}
	
	public void getDetails()
	{
		System.out.println("Employee Name "+name);
		System.out.println("Employee ID : "+empId);
		System.out.println("Basic Salary:"+basicSalary);
		
	}
	
	/*public void getDetails()
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the employee name");
		name=sc.next();
		System.out.println("Enter the employee id");
		empId=sc.next();
		System.out.println("Enter the basic salary of an employee");
		basicSalary=sc.nextInt();

	}*/
	
	public void calculation()
	{
		da=(30/100)*basicSalary;
		pf=(12/100)*basicSalary;
		hra=(15/100)*basicSalary;
		grossSalary=basicSalary+da+hra;
		netSalary=grossSalary-pf;
	}
	
	public void display()
	{
		System.out.println("Name"+name);
		System.out.println("Employee ID"+empId);
		System.out.println("Gross Salary"+grossSalary);
		System.out.println("Net Salary"+netSalary);
	}
	

	public static void main(String[] args) {

		Employee em=new Employee();
		em.calculation();
		em.display();
	}

}
