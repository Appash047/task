package programming_sessions;
import java.util.Scanner;
public class Vowel_String {


	static String ch;
	
	public static void input(String ch)
	{
		System.out.println("Enetered Charecter is : "+ch);
	}

	public static void check()
	{
		 int count=0;
		for(int i =0;i<ch.length();i++)
		{
	       
	    	if(ch.charAt(i)=='a'||ch.charAt(i)=='A'||ch.charAt(i)=='e'||ch.charAt(i)=='E'||ch.charAt(i)=='i'||ch.charAt(i)=='I'||ch.charAt(i)=='o'||ch.charAt(i)=='O'||ch.charAt(i)=='u'||ch.charAt(i)=='U')
		{   
			
		    count++;
			
		}
		
	    	
	 }
		System.out.println("Number of Vowels in Given Value is : "+count);
	}
	public static void main(String[] args) {
		
				Scanner sc=new Scanner(System.in);
				System.out.print("Enter a String : ");
				ch=sc.next();
				sc.close();
				input(ch);
				check();

				
			}

		}

	
