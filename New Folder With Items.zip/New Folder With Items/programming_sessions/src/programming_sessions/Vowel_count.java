package programming_sessions;
import java.util.Scanner;
public class Vowel_count {
	static char ch;
	
	public static void input(char ch)
	{
		System.out.println("Enetered Charecter is : "+ch);
	}

	public static void check()
	{
		int count=0;
		if(ch=='a'||ch=='A'||ch=='e'||ch=='E'||ch=='i'||ch=='I'||ch=='o'||ch=='O'||ch=='u'||ch=='U')
		{
			System.out.println(ch+" is a vowel");
			count++;
			System.out.println("the count of vowels is : "+count);
		}
		else {
			System.out.println(ch+" is not a vowel");
		}
	}

	public static void main(String[] args) {
		
	
				Scanner sc=new Scanner(System.in);
				System.out.print("Enter a character : ");
				ch=sc.next().charAt(0);
				sc.close();
				input(ch);
				check();

				
			}

		}

	
