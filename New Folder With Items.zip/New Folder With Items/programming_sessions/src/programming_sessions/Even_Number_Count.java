package programming_sessions;

import java.util.Scanner;

public class Even_Number_Count {

	public static void main(String[] args) {

		

				Scanner sc =new Scanner (System.in);
				int m,n;
				int count=0;
				System.out.print("Enter the Starting Number : ");
				m=sc.nextInt();
				System.out.print("Enter the Ending Number : ");
				n=sc.nextInt();
				sc.close();

			    if(m>n)
			    {
				  System.out.println("The even number from "+m+"to"+n+"are");
				  for(int i=m;i>=n;i--)
				    {
				    	if(i%2==0)
				    	{
						  System.out.println(i);
						  count++;
						  System.out.print("The total Even numbers are : "+count);

					    }
				    }
			    
			   }
			    
			    else if(m<n)
			    {
				  System.out.println("The even number from "+m+"to"+n+"are");
				  for(int i=m;i<=n;i++)
				    {
				    	if(i%2==0)
				    	{
						  System.out.println(i);
						  count++;
						  System.out.print("The total Even numbers are : "+count);

					    }
				    }
			    
			   }
			    
			    else 
			    {
				  System.out.println("Kindly Enter the Different Values...");
				 
			   }

			}

		}
