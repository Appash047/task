package programming_sessions;

public class Prime {
	int n;

	Prime() {
		n = 0;
	}

	void input(int x) {
		n = x;
	}

	void display() {
		int factor = 0;
		for (int i = 1; i <= n; i++) {
			if (n % i == 0)
				factor = factor + 1;
		}
		if (factor == 2)
			System.out.println(n + "  is a prime number");
		else
			System.out.println(n + "  is not a prime number");

	}

	public static void main(String[] args) {

		Prime p2 = new Prime();
		p2.input(10);
		p2.display();

	}

}
