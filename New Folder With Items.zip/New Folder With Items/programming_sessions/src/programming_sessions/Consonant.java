package programming_sessions;

import java.util.Scanner;

public class Consonant {
	

		static String ch;
		
		public static void input(String ch)
		{
			System.out.println("Enetered the paragraph is : "+ch);
		}

		public static void check()
		{
		    int count=0;
			for(int i =0;i<ch.length();i++)
			{
		       
		    	if(ch.charAt(i)!='a'||ch.charAt(i)!='A'||ch.charAt(i)!='e'||ch.charAt(i)!='E'||ch.charAt(i)!='i'||ch.charAt(i)!='I'||ch.charAt(i)!='o'||ch.charAt(i)!='O'||ch.charAt(i)!='u'||ch.charAt(i)!='U')
			        {   
				
			         count++;
				
			        }
			
		    	
		   }
			System.out.println("Number of consonant in Given Value is : "+count);
		}
		public static void main(String[] args) {
			
					Scanner sc=new Scanner(System.in);
					System.out.print("Enter a Paragraph : ");
					ch=sc.next();
					sc.close();
					input(ch);
					check();

					
				}

			}

		
	  