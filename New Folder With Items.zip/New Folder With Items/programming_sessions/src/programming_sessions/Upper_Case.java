package programming_sessions;

public class Upper_Case {
	

	public static void main(String[] args) {

	}

}
