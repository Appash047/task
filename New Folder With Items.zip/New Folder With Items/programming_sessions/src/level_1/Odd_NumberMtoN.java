package level_1;

import java.util.Scanner;

//program to display all the odd number between m to n

public class Odd_NumberMtoN {

	public static void main(String[] args) {

			

				Scanner sc =new Scanner (System.in);
				int m,n;
				System.out.print("Enter the Starting Number :");
				m=sc.nextInt();
				System.out.print("Enter the Ending Number :");
				n=sc.nextInt();
				sc.close();

				System.out.println("The Odd number");
				for(int i=m;i<=n;i++)
				{
					if(i%2!=0)
					{
						System.out.println(i);
					}
				}
			}

		}


