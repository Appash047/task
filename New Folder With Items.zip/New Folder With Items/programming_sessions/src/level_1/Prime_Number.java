package level_1;
import java.util.Scanner;
public class Prime_Number {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num;
		num=sc.nextInt();
		sc.close();
		
		for(int i=1;i<=num;i++)
		{
			if(i%num==0)
			{
				System.out.println(i);
			}
		}
		
	}

}
