package level_1;

public class Finalised {
	int x=10;
	@Override
	public void finalize()
	{
		System.out.println("Memory has been cleared");
	}

	@SuppressWarnings("null")
	public static void main(String[] args)throws Exception {
		 Finalised  d1=new  Finalised ();
		 System.out.println("Main start");
		 System.out.println(d1.x);
		 
		 d1=null;
		 System.gc();
		 System.out.println(d1.x);
		 Finalised  d2=new  Finalised ();

		 System.out.println(d2.x);


		// Thread.sleep(5000);
		 System.out.println("main ends");

		

	}

}
