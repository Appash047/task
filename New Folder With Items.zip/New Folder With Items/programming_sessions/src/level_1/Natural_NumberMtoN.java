package level_1;

import java.util.Scanner;

public class Natural_NumberMtoN {

	public static void main(String[] args) {

		Scanner sc=new Scanner (System.in);
		int m,n;
		System.out.print("Enter a starting Number : ");
		m=sc.nextInt();
		System.out.print("Enter a ending Number : ");
		n=sc.nextInt();
		sc.close();
		
		for(int i=m;i<=n;i++)
		{
			System.out.println(i);
		}
	}

}
