package level_1;
//program to display the first 10 natural numbers
public class For_Loop {

	public static void main(String[] args) {
		System.out.println("the first 10 natural numbers");

		for(int count=1;count<=10;count++)
		{
			System.out.println(count);
		}

	}

}
