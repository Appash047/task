package level_1;
//program to display all the even number between m to n
import java.util.Scanner;
public class Even_NumberMtoN {

	public static void main(String[] args) {

		Scanner sc =new Scanner (System.in);
		int m,n;
		System.out.print("Enter the Starting Number :");
		m=sc.nextInt();
		System.out.print("Enter the Ending Number :");
		n=sc.nextInt();
		sc.close();

		System.out.println("The even number");
		for(int i=m;i<=n;i++)
		{
			if(i%2==0)
			{
				System.out.println(i);
			}
		}
	}

}
