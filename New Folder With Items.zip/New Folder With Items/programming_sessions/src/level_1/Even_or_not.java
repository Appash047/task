package level_1;

import java.util.Scanner;

public class Even_or_not {

	public static void main(String[] args) {

		Scanner sc =new Scanner (System.in);
		int num;
		System.out.print("Enter the Number :  ");
		num=sc.nextInt();
		sc.close();
		
		if(num%2==0)
		{
			System.out.println(num+" is a Even Number");
		}
		else
		{
			System.out.println(num+" is not a Even Number");

		}
	}

}
