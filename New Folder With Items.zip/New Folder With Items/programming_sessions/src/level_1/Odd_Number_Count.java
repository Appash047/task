package level_1;

import java.util.Scanner;

public class Odd_Number_Count {

	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		int m,n;
		System.out.print("Enter the Starting Number : ");
		m=sc.nextInt();
		System.out.print("Enter the Ending Number : ");
		n=sc.nextInt();
		sc.close();
		int count=0;
		for (int i=m+1;i<n;i++)
		{
			if(i%2!=0)
			{
				System.out.println(i);
				count++;
			}
			
		}System.out.println("The count of Odd number  "+m+" to "+n+" is "+count);
	}

}
