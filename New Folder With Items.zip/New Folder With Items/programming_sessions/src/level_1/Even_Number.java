package level_1;
//program to display all the even number between 1 to 10
public class Even_Number {

	public static void main(String[] args) {

		System.out.println("The even Number 1 to 10 : ");
		for(int num=1;num<=10;num++)
		{
			if(num%2==0)
				System.out.println(num);
		}
	}

}
