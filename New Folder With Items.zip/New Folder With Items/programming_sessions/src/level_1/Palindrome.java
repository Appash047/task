package level_1;

import java.util.Scanner;
public class Palindrome {
	//program to accept a  number and display whether it is a palindrome or not 
	//Palindrome : original number = Reversed number 

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("\nEnter a Number to check Palindrome or Not : ");
		int num;
		num=sc.nextInt();
		sc.close();
		
		  int r,sum=0,temp;    
		  
		  
		  temp=num;    
		  while(num>0){    
		   r=num%10;  //getting remainder  
		   sum=(sum*10)+r;    
		   num=num/10;    
		  }    
		  if(temp==sum)    
		   System.out.println(temp+" is a palindrome number.... ");    
		  else    
		   System.out.println(temp+"is not palindrome.....");    

		
	}

}
