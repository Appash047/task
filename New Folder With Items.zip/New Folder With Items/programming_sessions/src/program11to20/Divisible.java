package program11to20;

import java.util.Scanner;

public class Divisible {

	public static void main(String[] args) {

		

		Scanner sc=new Scanner (System.in);
		int m,n;
		System.out.print("Enter a starting value of M : ");
		m=sc.nextInt();
		System.out.print("Enter a ending value of N: ");
		n=sc.nextInt();
		sc.close();
		int count=0;
		  if(m>n)
		    {
			  System.out.println("The total number from "+m+"to"+n+"are");
		      for (int i=m-1;i>n;i--)
	         	{
	   	        	if(i%3==0 && i%7==0)
			        {
 
		          	System.out.println(i);
		            count++;
		 	        }
		       } 
		   }
		  else  if(m<n)
		    {
			  System.out.println("The number from "+m+" to "+n+" are");

			  for (int i=m+1;i<n;i++)
	         	{
	   	        	if(i%3==0 && i%7==0)
			        {

		          	System.out.println(i);
		            count++;
		 	        }
		       } 
		    }
		  else
		  {
			  System.out.println("the given number is not  divisible by the 3 and 7 ");
		  }
			 
		System.out.println("the given numbers are divisible by the 3 and 7  is : "+count);
	}
	

}
