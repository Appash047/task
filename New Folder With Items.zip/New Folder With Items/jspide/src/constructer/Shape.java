package constructer;

/*
WAP  FOR THE BELOWE REQUIREMENT
CREATE A CLASS named as shape
Crate different type of shape object
Such as 
Rectangle
Triangle
Square*/

public class Shape {
	double l,b,s1,s2,s3,side;
	
	Shape(double l,double b)
	
	{
		this.l=l;
		this.b=b;
		
	}
	
	Shape(double s1,double s2,double s3)
	{
		this.s1=s1;
		this.s2=s2;
		this.s3=s3;
		
	}
	Shape(double side)
	{
		this.side=side;
		
	}
	void getShapeDetails()
	{
		System.out.println("length : "+l);
		System.out.println("Breadth :"+b);
		System.out.println("side1"+s1);
		System.out.println("side2 :"+s2);
		System.out.println("side3 :"+s3);
		System.out.println("side"+side);
	}
	

	public static void main(String[] args) {
		Shape square=new Shape(25);
		square.getShapeDetails();
		System.out.println("************************");
		Shape rectangle=new Shape(10,25);
		rectangle.getShapeDetails();
		System.out.println("************************");
		Shape triangle=new Shape(10,20,30);
		triangle.getShapeDetails();
		
	}

}
