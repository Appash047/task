package constructer;

public class SuperCall {
	
	SuperCall()
	{
		System.out.println("non-parameterised");
	}
	SuperCall(String str,int n)
	{
		System.out.println("String & int parametersed ");
		
	}
	SuperCall(int x)
	{
		System.out.println("int parameterised");
	}

	
}
