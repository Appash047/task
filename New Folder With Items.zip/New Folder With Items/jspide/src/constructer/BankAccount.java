package constructer;

public class BankAccount {
	String name;
	long mobileNum;
	long accNum;
	long adharNum;
	
	BankAccount(String name,long mobilNum,long mobileNum)
	{
		this.name=name;
	    this.accNum=accNum;
		this.mobileNum=mobileNum;
	}
	
	BankAccount(String name,long mobilNum,long mobileNum,long adharNum)
	{
		this.name=name;
	    this.accNum=accNum;
		this.mobileNum=mobileNum;
		this.adharNum=adharNum;
	
	}
	
	BankAccount(String name,long adharNum)
	{
		this.name=name;
	    this.adharNum=adharNum;
	}
	
	void getDetails()
	{
		System.out.println("Name "+name);
		System.out.println("Mobile Number: "+mobileNum);
		System.out.println("adhar Number :"+adharNum);
		System.out.println("Account Number :"+accNum);
	}

	public static void main(String[] args) {
		
		BankAccount user1=new BankAccount("appasha",868878502);
		user1.getDetails();
		BankAccount user2 =new BankAccount("Sujji",868878404,43434334);
		user2.getDetails();
		
	}

}
