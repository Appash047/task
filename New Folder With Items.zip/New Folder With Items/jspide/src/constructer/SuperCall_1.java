package constructer;

public class SuperCall_1 extends SuperCall {
	SuperCall_1(String a)
	{
		super();
		System.out.println("constucter of SuperCall_1 class");
		
	}
	
	
	public static void main(String[] args) {

		System.out.println("main starts");
		SuperCall_1 b1=new SuperCall_1("babaji");
		System.out.println("main ends");
	}

}
