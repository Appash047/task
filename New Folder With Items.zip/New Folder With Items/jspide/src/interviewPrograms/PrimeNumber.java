package interviewPrograms;
import java.util.Scanner;
class PrimeNumber {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int num;
		int count=0;
		System.out.println("Enter a number whethere Prime number or Not : ");
		num=sc.nextInt();
		if (num>0)
		{
			for(int i=1;i<=num;i++)
			{
				if(num%i==0)
				{
					count++;
				}
			}
		if(count==2)
		{
			System.out.println(num+"  is a Prime Number");
		}
		else
		{
			System.out.println(num+"  is not a Prime Number");
		}

	}
		else
		{
			System.out.println("Kindly enter Value greater than 0");
			
		}

}
}
