package interviewPrograms;

import java.util.Scanner;

public class EvenNumber {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);

		int n,m;

		System.out.print("Enter a number to get Even number from : ");
		
		n=sc.nextInt();
		System.out.print("to  : ");
		
		m=sc.nextInt();

		for(int i=n;i<=m;i++)
		{
			
			if(i%2==0)
			{
		System.out.print(i);
			}
			}
		
		}

	}


