package interviewPrograms;

import java.util.Scanner;
public class NaturalNumber {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		
		int n,m;
		System.out.print("Enter a number to get Natural number from : ");
	
		n=sc.nextInt();
		System.out.print("to  : ");
		
		m=sc.nextInt();
		for(int i=n;i<=m;i++)
			{
		
					System.out.print(i);
			}
	
	}

}
