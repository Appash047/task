package interviewPrograms;

import java.util.Scanner;

public class EvenNumberCount {

	public static void main(String[] args) {
		

		Scanner sc=new Scanner(System.in);

		int n,m;
        int count=0;
		System.out.print("Enter a number to get Even number  Between : ");
		
		n=sc.nextInt();
		System.out.print("to  : ");
		
		m=sc.nextInt();

		for(int i=n+1;i<m;i++)
		{
			
			if(i%2==0)
			{
		System.out.println(i);
		count++;
			}
		}
		System.out.println("The count of Even number is :  "+count);

	}

}
