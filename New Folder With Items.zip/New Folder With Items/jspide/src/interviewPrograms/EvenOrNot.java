package interviewPrograms;

import java.util.Scanner;
public class EvenOrNot {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int a;
		System.out.println("Enetr a Number to check Eeven or not  ");
		a=sc.nextInt();
		if(a%2==0)
		{
			System.out.println("the "+a+" is Even number");
		}
		else
		{
			System.out.println("the "+a+" is not Even number");
		}
				
		
		
	}

}
