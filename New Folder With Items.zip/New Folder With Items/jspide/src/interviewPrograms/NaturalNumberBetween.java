package interviewPrograms;

import java.util.Scanner;

   class NaturalNumberBetween {

	public static void main(String[] args) {
		
        Scanner sc=new Scanner(System.in);
		
		
		int n,m;
		System.out.print("Enter a number to get Natural number Between : ");
	
		n=sc.nextInt();
		System.out.print("to  : ");
		
		m=sc.nextInt();
		for(int i=n;i<m;i++) //for(int i=n+1;i<m;i++)
			{
			if(i==n)
			{
			continue;
			}
			else
			{
				System.out.print(i);
			}
			}
	
	}

   }

	


