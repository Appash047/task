package interviewPrograms;

import java.util.Scanner;

public class PrimeNumberBetween {


	 
	   public static void main(String[] args) {  
	       Scanner sc = new Scanner(System.in); 
	       int m,n;
	       System.out.print("Enter the first number : ");  
	       m = sc.nextInt();  
	       System.out.print("Enter the second number : ");  
	       n = sc.nextInt();  
	       System.out.println("List of prime numbers between " + m+ " and " + n);  
	       for (int i = m; i <= n; i++) {  
	           if (isPrime(i)) {  
	               System.out.println(i);  
	           }  
	       }  
	   }  
	   public static boolean isPrime(int n) {  
	       if (n <= 1) {  
	           return false;  
	       }  
	       for (int i = 2; i <= Math.sqrt(n); i++) {  
	           if (n % i == 0) {  
	               return false;  
	           }  
	       }  
	       return true;  
	   }  
	
	}

