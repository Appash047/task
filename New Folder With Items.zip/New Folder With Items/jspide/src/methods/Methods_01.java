package methods;
//WAP how many static methods declared in a program.
//ans :  n no.of static methods

// do we need to call all the static methods
// ans: yes,depends on the programs

// how many times we call a methods
// ans: n no.of times

// how many non-static methods defined in a program?

//how many time we can use non-static method in a program ?

//how do we access the non-static method in a program?

//can we call a method inside a loop
//ans:yes

//WAP to declare a static method and execute it 50 times

public class Methods_01 {
	
	public static void looping()
	{
		System.out.println("Hello..");
	}

	public static void main(String[] args) {
		
		for(int i=1;i<=10;i++)
		{
			looping();
		}
		
	}

}
