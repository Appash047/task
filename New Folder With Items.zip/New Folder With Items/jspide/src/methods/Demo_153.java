package methods;

//WAP for the below requirement
//create a class
//create two static methods and two non static methods
// access the first static method from the third method
//access the fourth method from the second method
// make the programe executable
public class Demo_153 {
	
	public static void m1()
	{
		System.out.println("first method");
	}
	public static void m2()
	{
		System.out.println("second method");
		new Demo_153().m4();
	}
	
	
	public void m3()
	{
		m1();
		System.out.println("third method");
	}
	public void m4()
	{
		System.out.println("fourth method");
		
	}

	public static void main(String[] args) {
		new Demo_153().m3();
		m2();
		
		
	}

}
