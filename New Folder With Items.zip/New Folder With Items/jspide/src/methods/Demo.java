package methods;
// accessing variable in a methode
//1.the variables which are declere inside any merhode are called as local variable,local variables can't be acces outside the methode 
//2.write the progrme for the belowe requirement
//create a static variable
//create a ststic methpde 
//acces the variable from the defind methode 
// call the methid from the main method

//
public class Demo {
	static int a=10;
	public static void m1()
	{
		System.out.println(a);
	}

	public static void main(String[] args) {
		
		m1();

	}

}// note : we can access the static variable from any static method within the same class
//when we want to access the static variable from the static method whithin the same class,we can access them directly
