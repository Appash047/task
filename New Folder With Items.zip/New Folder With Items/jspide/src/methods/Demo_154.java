package methods;
// Note Accessing   methods from other methods
//SM TO SM directly
//SM TO NSM directly
//NSM TO SM using object
//NSM TO NSM directly as well as using object



// * a static method can be access from another static method directly
// * a static method can be access from another non static method directly
// * a non static method can be access from static method using object
// * a non static method can be access from  another non static method by using object as well as directly


// Note : accessing variables from methods
//SV TO SM directly
//SV TO NSM directly
//NSV TO SM using object
//NSV TO NSM directly as well as using object

// WAP FOR THE BELOW REQUIREMENT
//create a class
//create a non static variable 
// create a static method
// access the non static variable from the static method

public class Demo_154 {
	
	int x=10;
	static void m1()
	{
		System.out.println(new Demo_154().x);
		//Demo_154 sc=new Demo_154();
	}

	public static void main(String[] args) {
		m1();

	}

}
