package methods;
//WAP for the below requirement
// create a non-static variable
// create a static method
//acces the non-static variable from the defind method
// cal the methid from the main method 
public class Demo_02 {
	int x=23;
	static void m1()
	{
		System.out.println(new Demo_02().x);
	}
	
	

	public static void main(String[] args) {

		m1();

	}

}
//note : non static variable can be access by using objects