package methods;
// WAP for below requirement
// create a class
// create a static method
//create a non-static method
// call the static method from the non-static method
// call the non static method from the main method
public class Demo_151 {
	public static void m1()
	{
		System.out.println("hello");
	}
	public  void m2()
	{
		
		
	m1();
	}

	public static void main(String[] args) {
		
		new Demo_151().m2();

	}

}
