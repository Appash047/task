package methods;
//WAP for the below requirement
//create a non static variable
//create a non static method
// access the non static variable from the non static method
// call the non static method from the main method of the class
public class Demo_155 {
	int x=100;
	void m1()
	{
		System.out.println(x);
	}

	public static void main(String[] args) {
		new Demo_155().m1();	
		}

}
