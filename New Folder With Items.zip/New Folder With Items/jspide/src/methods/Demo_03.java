package methods;

//WAP for the following requirement
//create a non-static variable 
//create a non -static method
// access the non static variable from the non static method 
// call the method from the main method

public class Demo_03 {
	int x=10;
	void m1()
	{
		//System.out.println(new Demo_03().x);
		System.out.println(x);
		//note: no static variavle can't be acces from the static method directluy
		//non-static vaiavble can acces from the non -static methode directly
		//static variables can be access derectly from the static method as well as from the non static method
	}

	public static void main(String[] args) {
		
		System.out.println();
		new Demo_03().m1();
		
		
	}

}
