package methods;
// WAP for the below requirement
//create a static variable 
//create non-static method
// acces the static variable from the non-static methode
// call the methid from the main method

public class Demo_01 {
	static int a=10;
	public void m1()
	{
		System.out.println(a);
	}

	public static void main(String[] args) {
		
	new Demo_01().m1();
		

	}

}
