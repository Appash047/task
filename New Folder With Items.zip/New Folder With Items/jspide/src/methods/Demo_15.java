package methods;

public class Demo_15 {
	
	public static void m1()
	{
		System.out.println("Hello1");
	}
	public static void m2()
	{
		m1();
	}

	public static void main(String[] args) {
		
		
		m2();
		
		
	}

}
