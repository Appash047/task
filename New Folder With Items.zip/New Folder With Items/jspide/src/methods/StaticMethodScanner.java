package methods;

public class StaticMethodScanner {

	public static void main(String[] args) {

	}

}
