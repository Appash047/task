package methods;

public class StaticMethods {
	
	public static void addition()
	{
		System.out.println("first Method");
	}
	public static void subtraction()
	{
		System.out.println("second Method");
	}

	public static void main(String[] args)
	{
		
		System.out.println("main start.....");
		addition();
		subtraction();
        System.out.println("main ends....");
		
		
	}

}
