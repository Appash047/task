package methods;

//WAP for the below requirement
// create two non static methods
//access the first non static method from the second non static method
// access the second method from the main method

public class Demo_152 {
	public void m1()
	{
		System.out.println("hello m1");
	}
	public void m2()
	{
		m1();
		
	}

	public static void main(String[] args) {
		
		new Demo_152().m2();

		
		
		
	}

}
