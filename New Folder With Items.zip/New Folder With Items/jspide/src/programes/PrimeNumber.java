package programes;
import java.util.Scanner;
public class PrimeNumber {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the given num value");
		int num=sc.nextInt();
		int factor=0;
		for(int i=1;i<=num/2;i++)
		{
			if(num%i==0)
			{
				factor++;
			}
			if(factor==0)
			{
				System.out.println(num+"is a prime number");
			}
		    else if (num%2==0)
			{
				System.out.println("the "+num+" is Even number");
			}
		    else if(num%2!=0)
			{
				System.out.println("the "+num+" is Odd number");
			} 
		    else 
		    {
		    	System.out.println("Try again");	
		    }
		}
		z
	}
}

		



