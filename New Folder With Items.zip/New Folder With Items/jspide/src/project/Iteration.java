package project;
import java.util.Scanner;

public class Iteration {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		String str;
		System.out.println("enetr a message");
		str=sc.nextLine();
		System.out.println("-----------");
		for(int d=1;d<=10;d++)
		{
			System.out.println(str);
		}
		
}

}
