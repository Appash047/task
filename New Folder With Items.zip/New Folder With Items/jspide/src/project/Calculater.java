package project;
import java.util.Scanner;

public class Calculater {

	public static void main(String[] args) {
		Scanner myObj = new Scanner(System.in);

		
		
		int a =10;
		int b=20;
		
		
		int option=5;
		
		switch (option)
		{

case 1:

	System.out.println(a+b);


break;

case 2:

	System.out.println(a-b);

	break;

case 3:

	System.out.println(a/b);

	break;

case 4:

	System.out.println(a*b);

	break;
	
default:
	System.out.println("wrong choice try again");

	}

	}
}
