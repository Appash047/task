package project;

public class GreaterNumber {

	public static void main(String[] args) {
		
		
		int a,b,c;
		a=10;
		b=20;
		c=30;
		
		if(a>=b && a>=c)  
		{
		System.out.println(a+" is the largest Number");  
		}
		else if (b>=a && b>=c)  
		{
			System.out.println(b+" is the largest Number");  
		}
		else  
			
			System.out.println(c+" is the largest number");  
			}  

	}


