package project;
import java.util.Scanner;

public class EvenNumber {

	public static void main(String[] args) {
		

		
		
		
		
		Scanner sc=new Scanner(System.in);
		int num;
		System.out.println("enter a number check weather it is even or not");
		num=sc.nextInt();
		if(num%2==0)
		{
		System.out.println(num+"is even number");
		}
		
	}
	
		
	}


