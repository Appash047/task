package project;

public class NestedIf {

	public static void main(String[] args) {
		int a=10;
		int b=20;
	a=a+10;
	b=b-10;
	System.out.println(a);
	System.out.println(b);
	
	
		
	}

}
