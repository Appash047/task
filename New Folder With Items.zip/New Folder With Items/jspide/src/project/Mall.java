package project;

public class Mall {

	public static void main(String[] args) {
	
		
		int rate=1000;
		int Discount=10;
		int totalcost;
		
		if (rate<=1000)
		{
			System.out.println(rate+"  discount 10% is = "+rate*10/100);
			System.out.print("Total cost  :");
			System.out.println(totalcost=rate+Discount);
		}
		

	}

}
