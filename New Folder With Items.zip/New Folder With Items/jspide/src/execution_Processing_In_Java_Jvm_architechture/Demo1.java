package execution_Processing_In_Java_Jvm_architechture;
// whenever java program is given to jvm for execution then the jvm calls three main resources to successfully execute the programe
// the three main resources are :
//1. class loader
//2. main method
//3. garbage collector


// class loader: it is the first resource called by jvm
//the job role of class loader is to load all the static member into static pool area 

//main method : it is the second resource call by jvm
// the main  method is call to start the execution of logic provided in the program

//garbage collector : it is the last resource called by jvm  to clear the memory

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}


// multi leven inheriitens