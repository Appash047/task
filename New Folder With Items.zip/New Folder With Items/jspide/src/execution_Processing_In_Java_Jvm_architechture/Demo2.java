package execution_Processing_In_Java_Jvm_architechture;

public class Demo2 {

	public static void main(String[] args) {
		int i;

		for (i=1;i<6;i++)
		{
			if(i>3)continue;
		}
		System.out.println(i);
		}
	}


