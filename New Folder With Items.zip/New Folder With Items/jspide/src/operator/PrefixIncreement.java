package operator;

public class PrefixIncreement {

	public static void main(String[] args) {
		
		
		int a =1;
		System.out.println(++a);//a=2
		System.out.println(++a+a);//a=3
		System.out.println(a+++a);//a=4
		System.out.println(a+++a+++a+a);//a=6
		System.out.println(a+a+++a+a);//a=7
	}

}
