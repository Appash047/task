package staticandnonstatic;
//WAP for the following requirement:
//1.Create SV
//2. Create NSV
//Access both the variable from main method

public class GlobalVarablePractice {
	static int x;
	int y;
	

	public static void main(String[] args) {
		System.out.println(x);
		
		//GlobalVarablePractice nonStaticVarable =new GlobalVarablePractice();
		//nonStaticVarable.y=10;
		//System.out.println(nonStaticVarable.y);
		//or
		System.out.println(new GlobalVarablePractice().y);
		
	}

}
