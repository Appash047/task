package staticandnonstatic;

public class DevelopmentStundent {
	
	//give the belowe programe is to  demonstrate the static variable which are getting
	
	String studentName;
	int age;
	int yop;
	String stream;
	static String javaFacaulty="Jagannath";
	

	public static void main(String[] args) {
		
		DevelopmentStundent s1=new DevelopmentStundent();
		System.out.println("Name of the Java Faculty for s1 :"+javaFacaulty);
		
		System.out.println(s1);
		
		DevelopmentStundent s2=new DevelopmentStundent();
		s2.age=20;
		System.out.println("Age of Student :"+s2.age);
		
		
		
		
		
		
	}

}
