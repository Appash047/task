package staticandnonstatic;

public class Student {
	
	//Generally we take NSv whenever the data is different for object
	//NSV should never be intialised during declerationm ,otherwise the data 
	//will common for allthe objects.
	//for example: the given belowe programe demonstrait how the NSV name is making the data
	//common for all the object of Student
	
	//String stdName="PushpaRaj";
	String stdName;

	

	public static void main(String[] args) {
		
		Student s1=new Student();
		s1.stdName="Raju\n";
		
		Student s2=new Student();
		s2.stdName="kaju\n";
		
		Student s3=new Student();
		s3.stdName="Dabba\n";
		
		Student s4=new Student();
		s4.stdName="Anna\n";
		
		Student s5=new Student();
		s5.stdName="Akka\n";
		
		Student s6=new Student();
		s6.stdName="Vishwa\n";
		
		System.out.println("Name of first student :"+s1.stdName);
		System.out.println("Name of first student :"+s2.stdName);
		System.out.println("Name of first student :"+s3.stdName);
		System.out.println("Name of first student :"+s4.stdName);
		System.out.println("Name of first student :"+s5.stdName);
		System.out.println("Name of first student :"+s6.stdName);
	
		
		// hear the data becoming common for all the object
		// to over come this problem we should use following techniques 
		// to keep the data different for all the objects by initialising
		//the NSV one by one for each and every object after the decleration of object
	}

}
