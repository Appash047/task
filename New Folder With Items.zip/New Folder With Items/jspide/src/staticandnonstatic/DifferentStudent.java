package staticandnonstatic;

public class DifferentStudent {
	
	String stdName;
	int age;
	int dob;
	int yop;
	
	DifferentStudent(String stdName,int age,int dob,int yop)//constructor used to initialise the variable
	{
		this.stdName=stdName;
		this.age=age;
		this.dob=dob;
		this.yop=yop;
	}
	

	void displayDetails()
	{
		System.out.println("NAme  : "+stdName);
		System.out.println("Age   : "+age);
		System.out.println("D.O.B : "+dob);
		System.out.println("Y.O.P : "+yop);
		
	}
	public static void main(String[] args) {
		
		DifferentStudent s1=new DifferentStudent("Appi",23,1999,2022);
		s1.displayDetails();
		System.out.println("------------\n");
		
		DifferentStudent s2=new DifferentStudent("Sujji",22,1999,2022);
		s2.displayDetails();
		System.out.println("------------\n");
		
		DifferentStudent s3=new DifferentStudent("Mallesh",22,1999,2022);
		s3.displayDetails();
		System.out.println("------------\n");
		
		DifferentStudent s4=new DifferentStudent("Vishwa",22,1999,2022);
		s4.displayDetails();
		System.out.println("------------\n");
		
		DifferentStudent s5=new DifferentStudent("Venky",22,1999,2022);
		s5.displayDetails();
		
	}

}
