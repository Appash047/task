package staticandnonstatic;

public class Car {
	static int noOfWheels=4;
	int noOfGears;
	


	public static void main(String[] args) {
		
		Car bmw=new Car();
		System.out.println("no. of wheels of bmw are :  "+noOfWheels);
		
		bmw.noOfGears=5;
		System.out.println("No. of Gears in bmw are : "+bmw.noOfGears);
		
		Car audi= new Car();
		System.out.println("no. of Wheels of Audi are :"+noOfWheels);
		
		audi.noOfGears=4;
		System.out.println("no. of Gears of Audi are : "+audi.noOfGears);
		
		Car gt=new Car();
		System.out.println("no. of wheels of gt are :"+noOfWheels);
		
		gt.noOfGears=6;
		System.out.println("no. of gears of gt are :"+gt.noOfGears);
	
		
		
	}

}
