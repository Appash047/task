package staticandnonstatic;

public class Flower {
	String name;
	int noOfPetals;
	String color;
	double size;

	public static void main(String[] args) {
		
		Flower lotus=new Flower();
		lotus.name="Lotus";
		lotus.noOfPetals=25;
		lotus.color="White";
		lotus.size=5;
		
		System.out.println("NAme of flower"+lotus.name);
		
		
		
		
		
		
		
	}

}
