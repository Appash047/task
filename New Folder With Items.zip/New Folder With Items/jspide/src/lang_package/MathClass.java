package lang_package;

public class MathClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
