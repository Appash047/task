package lang_package;

import java.util.Scanner;

public class UpperCase03 {

	public static void main(String[] args) {
		

		char ch;
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter a letter to check whether its uppercase or not");
		ch=sc.next().charAt(0);
		int asciiValue=ch;
		if(asciiValue>=97 && asciiValue<=122)
		{
		System.out.println(ch+" is in uppercase. ");
		}
		else
		{
		System.out.println(ch+" is not in uppercase");
		}
	}

}
