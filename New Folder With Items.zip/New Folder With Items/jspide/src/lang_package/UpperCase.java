package lang_package;

import java.util.Scanner;

public class UpperCase {

	public static void main(String[] args) {

		
		char ch;
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter a letter to check whether its uppercase or not");
		ch=sc.next().charAt(0);
		for(char i='A';i<='Z';i++)
		{
		if(ch==i)
		{
			
		System.out.println(ch+" is in uppercase. ");
		break;
		
		}
		else
		{
		System.out.println(ch+" is not in uppercase");
		}
	}

	}
}
