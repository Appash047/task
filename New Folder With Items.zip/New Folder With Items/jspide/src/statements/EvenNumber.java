package statements;

public class EvenNumber {

	public static void main(String[] args) {
		
		int a=10;
		if(a%2==0)
		{
			System.out.println(a+"is even number");
		}
		else
		{
			System.out.println(a+"is not even");
		}

	}

}
