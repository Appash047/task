package statements;

public class OddNumber {

	public static void main(String[] args) {
		
		int a= 9;
				
				
				if(a%2==0) {
					System.out.println(a+"is not odd");
				}
				else
				{
					System.out.println(a+"  is even");
				}
	}

}
