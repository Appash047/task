package statements;


	
		//Write a program to store 2 number and display the smallest number among  them

		class SmallerNumber
		{
		public static void main (String args[]) 
		{
		int a, b;
		a =10;
		b= 20;
		if(a>b)
		{
		System.out.println(a+"is not smaller");
		}
		else
		{
		System.out.println(b+"    is smaller");
		}
		}
		

	}


