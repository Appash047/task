package statements;

public class MonthsIfElseIf {
	public static void main(String [] args) {
	int month =8;
	
	if(month==1)
	{
		System.out.println("january");
	}
	
	else if(month==2) {
		System.out.println("february");
     }


    else if(month==3) {
	    System.out.println("march");
   }
   
   else if(month==4) {
	    System.out.println("march");
  }
   
   else if(month==5) {
	    System.out.println("march");
  }
   
   else if(month==6) {
	    System.out.println("march");
  }
   
   else if(month==7) {
	    System.out.println("march");
  }
   
   else if(month==8) {
	    System.out.println("march");
  }
   
   else if(month==9) {
	    System.out.println("march");
  }
   
   else if(month==10) {
	    System.out.println("march");
  }
   
   else if(month==11) {
	    System.out.println("march");
  }
   
   else if(month==12) {
	    System.out.println("march");
  }
   
   
   else {
	   System.out.println("Wrong choice! try again");
	   
   }
   }
   }
   

