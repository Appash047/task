package statements;

		class Numbercomparision
		{
		public static void main(String args[])
		{
		int num1=15;
		int num2=10;
		int sum=num1+num2;
		{
		System.out.println("sum of "+num1+" and "+num2+" is:"+sum);
		}
		if(num1>num2)
		{
		System.out.println(num1+"is greater than"+num2);
		}
		else if(num1<num2)
		{
		System.out.println(num2+"is greater than"+num1);
		}
		else
		{
		System.out.println(num1+"is equal to"+num2);
		}
		}
		
	}


