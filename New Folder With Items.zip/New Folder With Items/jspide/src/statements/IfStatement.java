package statements;

public class IfStatement {

	public static void main(String[] args) {
	
		int a,b;
		a=10;
		b=20;
		
		if(a>b)
		{
			System.out.println("hhh");
		
		}
	
		else {
			System.out.println("hhhhh");
			
		
		
		}
	}

}
