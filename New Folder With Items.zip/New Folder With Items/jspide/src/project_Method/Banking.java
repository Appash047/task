package project_Method;

public class Banking {
	public static void withdrawMoney(long accnum)
	{
		System.out.println("Money  withdraewn using a/c number. "+accnum);
	}
	
	public static void withdrawMoney(String UPI,int OTP)
	{
		System.out.println("Money  withdraewn using UPI. "+UPI+"and OTP "+OTP);
	}
	
	public static void withdrawMoney(String cheque)
	{
		System.out.println("Money  withdraewn using cheque. "+cheque);
	}
	
	public static void withdrawMoney(String UID,String pwd)
	{
		System.out.println("Money  withdraewn using a/c number. "+UID+"and pwd"+pwd);
	}
	

}
