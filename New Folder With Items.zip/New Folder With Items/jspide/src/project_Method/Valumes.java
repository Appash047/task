package project_Method;

import java.util.Scanner;
public class Valumes {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	
		
		System.out.println("\n****  Welcome to Volume finder Project   ****");
		System.out.println("----------------------------------------------\n");
		System.out.println(" * What you want to find  ?         ");
		System.out.println("(1)-> To find volume of Sphere  ");
		System.out.println("(2)-> To find Volume of Cylinder ");
		System.out.println("(3)-> To find Volume of Cuboid \n");
		System.out.print("Enter your Choice : ");


		int choice =sc.nextInt();
	
			switch(choice)
			{
			case 1:
				System.out.println("You have Entered choice "+choice+" to find the volume of Sphere ");
				System.out.print("\nEnter The Radius Value :  ");
				double radius =sc.nextDouble();
				double sphere=(4/3)*(22.0/7.0)*radius*radius*radius;
				System.out.println("The Sphere volume is : "+sphere);
				System.out.println("----------------------------------------------\n");
				break;
				
			case 2:
				System.out.println("You have Entered choice "+choice+" to find the volume of Cylinder ");
				System.out.print("\nEnter The Radius Value :  ");
			           radius =sc.nextDouble();
				System.out.print("Enter The Height Value :  ");
				double height =sc.nextDouble();
				double cylinder=(22.0/7.0)*radius*radius*height;
				System.out.println("The Sphere volume is : "+cylinder);
				System.out.println("----------------------------------------------\n");
				break;
				
			case 3:
				System.out.println("You have Entered choice "+choice+" to find the volume of Cuboid ");
				System.out.print("\nEnter The Radius Value :  ");
			         	 radius =sc.nextDouble();
				System.out.print("Enter The Height Value :  ");
			             height =sc.nextDouble();
				System.out.print("Enter The Breadth Value :  ");
				double breadth =sc.nextDouble();
				double cuboid=radius*height*breadth;
				System.out.println("The Sphere volume is : "+cuboid);
				System.out.println("----------------------------------------------\n");
				break;

			 default:
				   
					System.out.println("\n Wrong choice! try again 🤪🤪 ");
			   
			}
			sc.close();
			System.out.println("***  Thank you For using our Application 🥳🥳 ***");
		}
		
			
	}

