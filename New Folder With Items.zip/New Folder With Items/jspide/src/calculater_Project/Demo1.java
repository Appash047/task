package calculater_Project;

public class Demo1 {
	
	
	public static void add(int num1,int num2)

	{
//		Scanner sc=new Scanner(System.in);
				
//		int sum=num1+num2;
		System.out.println("the sum of "+num1+ "of"+num2);
	}
	}


