package calculater_Project;
import java.util.Scanner;
public class FaceBookApp {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		sc.close();
		String name;
		long number;
		String mail_ID;
		System.out.println("login account");
		System.out.println("------------------------------------");
		System.out.print("enetr a name  :  ");
		name=sc.next();
		
		System.out.print("enetr a number  :  ");
		number=sc.nextLong();
		
		System.out.print("enetr a mail id  :  ");
		mail_ID=sc.next();
		
				

		System.out.print("forget password  :  ");
		mail_ID=sc.next();

		System.out.print("enetr your phone number to recive send otp  :  ");
		mail_ID=sc.next();

		System.out.print("enetr otp :  ");
		mail_ID=sc.next();

		System.out.print("enter new password :  ");
		mail_ID=sc.next();

		System.out.print("password changed sucessfully  :  ");
		mail_ID=sc.next();

		System.out.print("marchi pikkinava  :  ");
		mail_ID=sc.next();
		

		

		

		

		

		


	}

}
