package array;

import java.util.Scanner;

public class Array {
	

	

	public static void main(String[] args) {
    
		Scanner sc=new Scanner (System.in);
		
		System.out.println("select your choice");
		System.out.println("1. Even Number");
		System.out.println("2. Odd Number");
		System.out.println("3. AmStrong Number");
		System.out.println("4. Prime Number");
		System.out.println("5. Buzz Number");

	
		
		int arr []=new int [20];
			
				int choice =4;
				switch (choice)
				{
				case 1:
				System.out.println("January");
				break;
		        
				case 2:
			    System.out.println("February");
			    break;
		    
		    	case 3:
				System.out.println("March");
		        break;
		      
			    case 4:
				System.out.println("April");
		    
			    case 5:
				System.out.println("May");
		        
			    default:
		   
				System.out.println("Wrong choice! try again");
		   

			}
			}

		

		
		
	}

