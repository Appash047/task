package array;
import java.util.Scanner;
public class Selection_Short {

	public static void main(String[] args) {
		{
			int marks[]=new int [10];
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter students marks");
			for(int i=0;i<marks.length;i++)
			{
				marks[i]=sc.nextInt();
			}
		for(int j=0;j<10;j++)
		{
			int min=j;
			for(int k=j+1;k<10;k++)
			{
				if(marks[k]<marks[min]) {
					min=k;
				}
					
			}
			int temp=marks[j];
			marks[j]=marks[min];
			marks[min]=temp;
		}
		System.out.println("higest marks scored in mathametics is:"+marks[9]);
			
		}
	}
}
