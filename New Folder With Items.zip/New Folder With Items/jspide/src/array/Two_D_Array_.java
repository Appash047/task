package array;

import java.util.Scanner;

public class Two_D_Array_ {

	public static void main(String[] args) {
 
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter a elements to a array");
		 int arr[][]=new int [3][3];
		 int sum=0;
		 for(int i =0;i<3;i++)
		 {
			 for(int j=0;j<3;j++)
			 {
					arr[i][j]=sc.nextInt();
			 }
		 }
		 System.out.println("Elements in from matrics");
			for(int i=0;i<3;i++)
			{
				for(int j=0;j<3;j++)
				{
					System.out.print(arr[i][j]+"  ");

				}
				System.out.println();
	        }
			for(int i=0;i<3;i++)
			{
				for(int j=0;j<3;j++)
				{
					sum=sum+arr[i][j];
				}

            }
			
			System.out.println(" the sum of array element are "+sum);
    }
}
