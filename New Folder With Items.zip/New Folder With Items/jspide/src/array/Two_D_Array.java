package array;

import java.util.Scanner;

public class Two_D_Array {

	public static void main(String[] args) {
		
         
		Scanner sc =new Scanner (System.in);
		int arr[][]=new int [3][4];
		System.out.println("Enetr a Row and Coloums values : ");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<4;j++)
			{
				arr[i][j]=sc.nextInt();
			}
		}
		System.out.println("Elements in from matrics");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<4;j++)
			{
				System.out.print(arr[i][j]+"  ");

			}
			System.out.println();
		}
	}

}
