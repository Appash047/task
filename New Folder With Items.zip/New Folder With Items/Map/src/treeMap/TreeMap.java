package treeMap;

import java.util.Set;

public class TreeMap {

	public static void main(String[] args) {

//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter sorting way");
//		String s = sc.next();
//		Comparator<Student> c = new IdComparator();
//		if (s.equals("name")) {
//			c = new NameComparator();
//		} else if (s.equals("age")) {
//			c = new AgeComparator();
//		} else if (s.equals("marks")) {
//			c = new MarksComparator();
//		}

//		System.out.println("Enter the number the which way you want to sort \n1.Name \n2.Age \n3.Marks");
//		int n = sc.nextInt();
//		Comparator<Student> c1 = new IdComparator();
//		if (n == 1) {
//			c1 = new NameComparator();
//		} else if (n == 2) {
//			c1 = new AgeComparator();
//		} else if (n == 3) {
//			c1 = new MarksComparator();
//		}

		java.util.TreeMap<Student, Integer> tm = new java.util.TreeMap<>(new MarksComparator());
		tm.put(new Student(1, "Appi", 23, 66), 1);
		tm.put(new Student(3, "Appu", 23, 89), 2);
		tm.put(new Student(2, "Appash", 23, 83), 3);
		tm.put(new Student(5, "Salli", 23, 66), 4);
		tm.put(new Student(4, "mallu", 23, 66), 5);

		Set<Student> stu=tm.keySet();
		for(Student st:stu) {
			char ch=st.getName().charAt(0);
			if(ch=='S') {
				System.out.println(st);
			}
		}

	}

}
