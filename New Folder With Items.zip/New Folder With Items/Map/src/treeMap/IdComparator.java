package treeMap;

import java.util.Comparator;

public class IdComparator implements Comparator<Student> {

	public int compare(Student o1, Student o2) {
//		return o1.getId() - o2.getId();
		return o2.getId() - o1.getId();// for descending order
		
	}

}
