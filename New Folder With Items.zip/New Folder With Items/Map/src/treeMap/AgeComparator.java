package treeMap;

import java.util.Comparator;

public class AgeComparator implements Comparator<Student> {

	public int compare(Student o1, Student o2) {
//		return o1.getAge() - o2.getAge();
		return o2.getAge() - o1.getAge();
		
	}

}
