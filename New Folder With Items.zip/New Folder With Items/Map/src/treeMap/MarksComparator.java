package treeMap;

import java.util.Comparator;

public class MarksComparator implements Comparator<Student> {

	public int compare(Student o1, Student o2) {
//		return (int) (o1.getMarks() - o2.getMarks());
		return (int) (o2.getMarks() - o1.getMarks());

	}

}
