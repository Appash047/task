package treemap01;

import java.util.Comparator;
import java.util.Scanner;

import treeMap.IdComparator;
import treeMap.Student;

public class TreeMap {

	public static void main(String[] args) {

		

		
		
		
		
	}

}
