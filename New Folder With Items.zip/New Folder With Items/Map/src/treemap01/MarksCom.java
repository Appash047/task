package treemap01;

import java.util.Comparator;

public class MarksCom implements Comparator<Student> {

	public int compare(Student o1, Student o2) {
		return (int) (o2.getMarks() - o1.getMarks());
	}

}
