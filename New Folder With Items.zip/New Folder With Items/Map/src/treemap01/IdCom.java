package treemap01;

import java.util.Comparator;

public class IdCom implements Comparator<Student>{

	public int compare(Student o1, Student o2) {
		return o2.getId()-o1.getId();
	}
	

}
