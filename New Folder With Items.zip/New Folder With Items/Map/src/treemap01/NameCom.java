package treemap01;

import java.util.Comparator;

public class NameCom implements Comparator<Student> {

	public int compare(Student o1, Student o2) {
		return (int) (o2.getName().compareTo(o1.getName()));
	}

}
