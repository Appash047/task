package hashMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Demo1 {

	public static void main(String[] args) {

		Map<Integer, String> m = new HashMap<Integer, String>();
		m.put(2, "A");
		m.put(4, "B");
		m.put(1, "C");
		m.put(3, "D");
		m.put(5, "E");
		m.put(6, "F");

		List<Integer> s = new ArrayList<Integer>();
		s.add(1);
		s.add(3);
		s.add(2);
		s.add(1);
		s.add(4);
		s.add(5);
		s.add(2);
		s.add(6);

		System.out.println(s);
		System.out.println(m);

		String res = "";
		for (Integer i : s) {
			if (m.containsKey(i)) {
				res = res + m.get(i);

			}
		}
		System.out.println(res);

	}

}
