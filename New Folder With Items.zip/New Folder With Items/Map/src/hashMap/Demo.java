package hashMap;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Demo {

	public static void main(String[] args) {

		Map<Integer, String> m=new HashMap<Integer, String>();
		m.put(1, "Appi");
		m.put(4, "Appu");
		m.put(3, "Malli");
		m.put(9, "mallu");
		System.out.println(m);
		Map<Integer, String> m1=new HashMap<Integer, String>();
		m.put(2, "Appi");
		m.put(5, "Appu");
		m.put(6, "Malli");
		m.put(8, "mallu");
		System.out.println(m1);
		
		m.putAll(m1);
		System.out.println(m);
		
		Set entris=m.entrySet();
		System.out.println(entris);
		
		for(Object o:entris) {
			System.out.println(o);
		}
		
		Set keys=m.keySet();
		System.out.println(keys);
		for(Object o:keys) {
			System.out.println(o+" : "+m.get(o));
		}
		
		Collection c=m.values();
		System.out.println(c);
		
	}

}
