package numberPatterns;

public class P1 {

	public static void main(String[] args) {

		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 5; j++) {
				System.out.print(" " + i);
			}
			System.out.println();
		}
		System.out.println("********************");

		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 5; j++) {
				System.out.print(" " + j);
			}
			System.out.println();
		}
		System.out.println("********************");

		for (int i = 5; i >= 1; i--) {
			for (int j = 1; j <= 5; j++) {
				System.out.print(" " + i);
			}
			System.out.println();
		}
		System.out.println("********************");

		for (int i = 5; i >= 1; i--) {
			for (int j = 5; j >= 1; j--) {
				System.out.print(" " + j);
			}
			System.out.println();
		}
		System.out.println("********************");

		int n = 1;
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 5; j++) {
				System.out.print("  " + n);
				n++;
			}
			System.out.println();
		}
		System.out.println("********************");
		int m = 1;
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 5; j++) {
				System.out.print(" "+m);
				m += 2;
			}
			System.out.println();
		}
		System.out.println("********************");
		int o = 2;
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 5; j++) {
				System.out.print(" "+o);
				o +=2 ;
			}
			System.out.println();
		}

	}
}
