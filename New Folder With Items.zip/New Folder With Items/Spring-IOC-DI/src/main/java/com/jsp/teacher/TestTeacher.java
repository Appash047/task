package com.jsp.teacher;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestTeacher {

	public static void main(String[] args) {

		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("cdi.xml");
		Teacher teacher=(Teacher) applicationContext.getBean("tea1");
		teacher.display();
		
	}

}
