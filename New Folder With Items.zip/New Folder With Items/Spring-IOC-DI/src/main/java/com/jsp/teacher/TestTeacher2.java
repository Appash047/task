package com.jsp.teacher;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestTeacher2 {

	public static void main(String[] args) {

		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("cdi.xml");
		Teacher2 teacher2=(Teacher2) applicationContext.getBean("tea2");
		teacher2.display();
	}

}
