package com.jsp.car;

public class MusicPlayer {

	public void play() {
		System.out.println("Kavithe Kavithe............");
	}

}
