package com.jsp.teacher;

public class Teacher {

	int id;
	String name;
	double sal;

	public Teacher(int id, String name, double sal) {
		this.id = id;
		this.name = name;
		this.sal = sal;
	}

	public void display() {
		System.out.println("Teacher id : " + id);
		System.out.println("Teacher name : " + name);
		System.out.println("Teacher salary : " + sal);

	}

}
