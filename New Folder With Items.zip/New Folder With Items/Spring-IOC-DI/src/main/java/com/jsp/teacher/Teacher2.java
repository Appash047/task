package com.jsp.teacher;

public class Teacher2 {

	int id;
	String name;
	double sal;

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setSal(double sal) {
		this.sal = sal;
	}

	public void display() {
		System.out.println("Teacher id : " + id);
		System.out.println("Teacher name : " + name);
		System.out.println("Teacher salary : " + sal);

	}
}
