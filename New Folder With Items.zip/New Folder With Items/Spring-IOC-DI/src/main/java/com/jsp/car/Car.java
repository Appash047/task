package com.jsp.car;

public class Car {

	MusicPlayer musicPlayer;

	public void setMusicPlayer(MusicPlayer musicPlayer) {
		this.musicPlayer = musicPlayer;
	}

	public void run() {
		musicPlayer.play();
	}
}
