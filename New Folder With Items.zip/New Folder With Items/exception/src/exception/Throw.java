package exception;

public class Throw extends Exception{


	
		

}
