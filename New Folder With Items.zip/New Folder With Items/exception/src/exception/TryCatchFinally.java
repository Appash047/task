package exception;

public class TryCatchFinally {

	public static void main(String[] args) {

		System.out.println("hello");
		System.out.println("hello");
		System.out.println("hello");
		System.out.println("hello");
		int n = 10;
		try {

			System.out.println(n / 0);

		} catch (Exception c) {
			System.out.println(c);
		}	
		finally {
			System.out.println("print it");
		} 
		System.out.println("hello");
		System.out.println("hello");
		System.out.println("hello");
		System.out.println("hello");
	
			
		
	}

}
