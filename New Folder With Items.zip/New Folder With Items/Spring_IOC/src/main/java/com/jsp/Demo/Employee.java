package com.jsp.Demo;

public class Employee {

	public void test() {

		System.out.println("Hello");
	}
}
