package com.jsp.j2ee;

public class Employee {

	public void test() {
		System.out.println("Helloo");
	}
}
