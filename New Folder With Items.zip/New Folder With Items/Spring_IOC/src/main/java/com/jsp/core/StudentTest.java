package com.jsp.core;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class StudentTest {

	public static void main(String[] args) {


		ClassPathResource classPathResource=new ClassPathResource("spring.xml");
		BeanFactory beanFactory=new XmlBeanFactory(classPathResource);
		Student student= (Student)beanFactory.getBean("stu1");
		student.test();
	}
}


