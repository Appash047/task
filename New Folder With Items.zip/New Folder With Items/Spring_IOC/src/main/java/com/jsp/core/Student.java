package com.jsp.core;

public class Student {
	
	public void test() {
		System.out.println("Hello");
	}

}
