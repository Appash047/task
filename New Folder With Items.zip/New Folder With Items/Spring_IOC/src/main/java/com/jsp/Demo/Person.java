package com.jsp.Demo;

public class Person {

	public void test1() {
		System.out.println("hello2");
	}
}
