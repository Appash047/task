package com.jsp.j2ee;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class EmployeeTest {

	public static void main(String[] args) {

//		ClassPathResource classPathResource=new ClassPathResource("j2eecontainer.xml");
//		BeanFactory beanFactory=new XmlBeanFactory(classPathResource);
//		Employee employee=(Employee) beanFactory.getBean("emp");
//		employee.test();
		
		
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("j2eecontainer.xml");
		Employee employee=(Employee) applicationContext.getBean("emp");
		employee.test();
		
	}

}
