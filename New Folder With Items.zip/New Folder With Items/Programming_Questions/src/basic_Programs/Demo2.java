package basic_Programs;

public class Demo2 {

	public static void main(String[] args) {

		int a=10;
		int b=20;
		
		System.out.println(a);
		System.out.println(b);
		System.out.println("-----------");
		
		a=a-b;
		b=
		
	}

}
