package com.jsp.Demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Aadhar {
@Id
@GeneratedValue
private int id;
private String fathername;
private String address;

@OneToOne(mappedBy = "person")
@JoinColumn
private Person person;


public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public Person getPerson() {
	return person;
}
public void setPerson(Person person) {
	this.person = person;
}
public int getSerialNo() {
	return id;
}
public void setSerialNo(int id) {
	this.id = id;
}
public String getFathername() {
	return fathername;
}
public void setFathername(String fathername) {
	this.fathername = fathername;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}


}
