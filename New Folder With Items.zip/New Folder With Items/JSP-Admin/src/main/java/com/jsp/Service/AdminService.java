package com.jsp.Service;

import java.util.List;

import com.jsp.dao.AdminDao;
import com.jsp.dto.Admin;

public class AdminService {

	AdminDao adminDao = new AdminDao();

	public Admin save(Admin admin) {
		return adminDao.save(admin);
	}

	public List<Admin> display() {
		return adminDao.display();
	}

	public Admin find(int id) {
		return adminDao.find(id);
	}

	public Admin update(Admin admin) {
		return adminDao.update(admin);
	}

	public Admin delete(int id) {
		return adminDao.delete(id);
	}
}