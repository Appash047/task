package com.jsp.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jsp.Service.AdminService;
import com.jsp.dto.Admin;

@WebServlet("/save")
public class Save extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		Admin admin = new Admin();
		admin.setId(Integer.parseInt(req.getParameter("id")));
		admin.setName(req.getParameter("name"));
		admin.setEmail(req.getParameter("email"));
		admin.setPassword(req.getParameter("password"));

		AdminService adminService = new AdminService();
		Admin admin2 = adminService.save(admin);
		if (admin2 != null) {
			RequestDispatcher requestDispatcher = req.getRequestDispatcher("Home.jsp");
			requestDispatcher.forward(req, resp);
		} else {
			RequestDispatcher requestDispatcher = req.getRequestDispatcher("Save.jsp");
			requestDispatcher.include(req, resp);
		}
	}
}
