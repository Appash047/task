package com.jsp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jsp.dto.Admin;
import com.mysql.cj.Query;

public class AdminDao {

	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("Appi");

	public Admin save(Admin admin) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		if (admin != null) {
			entityTransaction.begin();
			entityManager.persist(admin);
			entityTransaction.commit();
		}
		return admin;

	}

	public List<Admin> display() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		javax.persistence.Query query = entityManager.createQuery("select a from Admin a");
		return query.getResultList();
	}

	public Admin find(int id) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		return entityManager.find(Admin.class, id);

	}

	public Admin update(Admin admin) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		Admin admin2 = entityManager.find(Admin.class, admin.getId());
		if (admin2 != null) {
			entityTransaction.begin();
			entityManager.merge(admin);
			entityTransaction.commit();
		}
		return admin;
	}

	public Admin delete(int id) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		Admin admin = entityManager.find(Admin.class, id);
		if (admin != null) {
			entityTransaction.begin();
			entityManager.remove(admin);
			entityTransaction.commit();
		}
		return admin;
	}

}
