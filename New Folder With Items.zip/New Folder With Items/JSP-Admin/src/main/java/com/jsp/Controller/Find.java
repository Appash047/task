package com.jsp.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jsp.Service.AdminService;
import com.jsp.dto.Admin;

@WebServlet("/find")
public class Find extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		Admin admin = new Admin();

		int id = Integer.parseInt(req.getParameter("id"));
		admin.setId(id);

		AdminService adminService = new AdminService();
		Admin admin2= adminService.find(id);

		if(admin2 != null) {
			RequestDispatcher dispatcher=req.getRequestDispatcher("Find.jsp");
			dispatcher.forward(req, resp);
		}else {
			RequestDispatcher dispatcher=req.getRequestDispatcher("Home.jsp");
			dispatcher.include(req, resp);
		}
	}

}
