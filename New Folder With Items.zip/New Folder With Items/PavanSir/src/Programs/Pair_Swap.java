package Programs;

public class Pair_Swap {

	public static void main(String[] args) {
		
		int a[]= {4,2,0,1,7};
		for(int i=0; i<a.length;i++) {
			if(i%2==1) {
				System.out.println(a[i]+"  "+a[i-1]);
			}
		}
		
		if(a.length%2==1) {
			System.out.println(a[a.length-1]);
		}
	}

}
