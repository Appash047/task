package Programs;

public class Bubble_Sort {

	public static void main(String[] args) {
		
		int a[]= {1,6,7,5,4,3};
		for (int i=0; i<(a.length-1); i++) {
			for (int j=i; j<(a.length-i); j++) {
				if(a[j-1]>a[j]) {
					int temp=a[j-1];
					a[j-1]=a[j];
					a[j]=temp;
				}
				
			}
		}
		for(int i=0; i<a.length; i++) {
			System.out.println(a[i]+"  ");
		}
	}

}
