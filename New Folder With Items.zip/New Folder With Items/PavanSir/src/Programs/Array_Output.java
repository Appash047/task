package Programs;

public class Array_Output {

	public static void main(String[] args) {
		
			int a[]= {1,3,4,2,6,7,10,15,};
			int ec=0,oc=0;
			for(int i=0; i<a.length;i++) {
				if(a[i]%2==0) {
					ec++;
				}
				else {
					oc++;
				}
				
			}
			int[] earray= new int[ec];
			int[] oarray= new int[oc];
			for(int i=0,j=0,k=0;i<a.length;i++) {
				if(a[i]%2==0) {
					earray[j]=a[i];
					j++;
				}
				else {
					oarray[k]=a[i];
					k++;
				}
			}
			
			int res[]=new int[a.length];
			for(int i=0; i<earray.length; i++) {
				res[i]=earray[i];
			}
			
			for(int i=earray.length, j=0; j<oarray.length; i++, j++) {
				res[i]=oarray[j];
			
	}

}
}
