package Programs;

public class Selection_sort {

	public static void main(String[] args) {
		int a[]= {6,7,4,5,2};
		for(int i=0; i<(a.length-1); i++) {
			int m=i;
			for(int j=i+1; j<a.length; j++) {
				if(a[i]<a[m]) {
					m=j;
				}
			}
			int temp=a[i];
			a[i]=a[m];
			a[m]=temp;
		}
		
		for(int i=0; i<a.length; i++) {
			System.out.println(a[i]+ " ");
		}
	}

}
