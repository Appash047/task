package Programs;

public class Linear_Searching {

	public static void main(String[] args) {
		
		int a[]= {5,7,4,9,11};
		int ele=9;
		int ind=-1;
		for(int i=0; i<a.length;i++) {
			if(a[i]==ele) {
				ind=i;
				break;
			}
		}
		
		if(ind==-1) {
			System.out.println("element not found");
		}
		else {
			System.out.println("element is found at "+ind);
		}
	}

}
