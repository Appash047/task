package Programs;

public class Merge {

	public static void main(String[] args) {
		
		int a[]= {4,2,0,1,7};
		int b[]= {6,10,12,14,16,18};
		int res[]=new int[a.length+b.length];
		
		for(int i=0;i<a.length;i++) {
			res[i]=a[i];
		}
		for (int i=a.length, j=0;j<b.length; i++,j++ ) {
			res[i]=b[j];
		}
		
		for(int i=0; i<res.length; i++) {
			System.out.println(res[i]);
		}
	}

}
