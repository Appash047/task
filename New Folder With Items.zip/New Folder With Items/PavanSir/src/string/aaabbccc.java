package string;

public class aaabbccc {

	public static void main(String[] args) {

		String s = "aaabbccc";
		String res = "";
		int count = 1;
		char c = s.charAt(0);
		for (int i = 1; i < s.length(); i++) {
		    char curr = s.charAt(i);
		    if (curr == c) {
		        count++; // Increment the count if the current character is the same as the previous character
		    } else {
		        res += c + Integer.toString(count); // Add the previous character and its count to the output string
		        c = curr;
		        count = 1; // Reset the count for the new character
		    }
		}
		output += prev + Integer.toString(count); // Add the last character and its count to the output string
		System.out.println(output); // Prints "a3b2c3"

	}

}
