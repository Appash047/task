package string;

public class VovelConsonant {

	public static void main(String[] args) {

		String s1="abcdefgh";
		String s2="aeiouAEIOU";
		String s3="";
		String s4="";
		
		for(int i=0;i<s1.length();i++) {
			if(s2.indexOf(s1.charAt(i)) !=-1) {
				s3=s3+s1.charAt(i);
			}
			else {
				s4=s4+s1.charAt(i);
			}
		}
		System.out.println(s3+s4);
	}

}
