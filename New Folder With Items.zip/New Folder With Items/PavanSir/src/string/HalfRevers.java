package string;

public class HalfRevers {

	public static void main(String[] args) {

		String s1 = "abcdefgh";
		String s2 = "";
		String s3 = "";

		for (int i = 0; i < s1.length(); i++) {
			if (i < 4) {
				s2 = s2 + s1.charAt(i);
			} else {
				s3 =  s1.charAt(i)+s3;
				

			}
		}
		System.out.println(s2 + s3);
	}

}
