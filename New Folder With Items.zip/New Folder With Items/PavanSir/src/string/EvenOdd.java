package string;

public class EvenOdd {

	public static void main(String[] args) {

		String s1="abcdefgh";
		String s2="";
		String s3="";
		for(int i=0;i<s1.length();i++) {
			if(i%2==0) {
				s2=s2+s1.charAt(i);
			}
			else {
				s3=s3+s1.charAt(i);
			}
		}
		System.out.println(s2+s3);
	}

}
