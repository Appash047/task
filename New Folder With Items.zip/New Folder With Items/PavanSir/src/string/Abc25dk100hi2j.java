package string;

public class Abc25dk100hi2j {

	public static void main(String[] args) {

		String s = "abc25dk100hi2j";
		String res = "";
		int n = 0;
		for (int i = 1; i < s.length(); i++) {
			char ch = s.charAt(i);
			if (ch > 0 && ch < 9) {
				int c=1;
				for(int j=i;j<s.length();j++) {
					if(s.charAt(j)>0 && s.charAt(j)<9) {
						c++;
					}
					else {
						break;
					}
				}
				String s1=s.substring(i,i+c-1);
				n=Integer.parseInt(s1);
				for(int m=0;m<n;m++) {
					res=res+s.charAt(i-1);
				}
				i+=(c-1);
			}
			else {
				res=res+s.charAt(i-1);
			}
		}
		char ch1=s.

	}
}