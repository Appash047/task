package string;

public class EvenUpper {

	public static void main(String[] args) {

		String s1="abcdefgh";
		
		for(int i=0;i<s1.length();i++) {
			String s2="";
			String s3="";
			if(i%2==0) {
				s2=s2+s1.charAt(i);
				s2=s2.toUpperCase();
			}
			else {
				s3=s3+s1.charAt(i);
			}
			System.out.print(s2+s3);

		}
	}

}
