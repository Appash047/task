package string;

public class Test {
public static void main(String[] args) {
	String s="abc2dk10hi2j";
	String res="";
	int n=0;
	for(int i=0;i<s.length();i++) {

		char c=s.charAt(i);
		if(c>=0 && c<=9) {
			n=Integer.parseInt(c+"");
			for(int j=0;j<n;j++) {
				res=res+s.charAt(i);
			}
		}
	}
	System.out.println(res);
	
	
}
}
