package string;

public class a3b2c3 {

	public static void main(String[] args) {

		String s = "a3b2c3";
		String res = "";
		int n = 0;
		for (int i = 0; i < s.length(); i++) {

			if (i % 2 == 1) {
				n = Integer.parseInt(s.charAt(i) + "");
				for (int j = 1; j <= n; j++) {
					res = res + s.charAt(i - 1);
				}
			}
		}
		System.out.println(res);
		
		

	}
}