package string;

public class WordRevers {

	public static void main(String[] args) {
		

		String s="This is my world";
		String[] sar=s.split(" ");
		String res=" ";
		for(int i=0; i<sar.length;i++) {
			res=sar[i]+" "+res;
			
		}
		System.out.println("This is my world");
		System.out.println(res);
	}

}
