
package string;

public class SentensReverse {

	public static void main(String[] args) {
		
		String s="This is my world";
				String res=" ";
				String[] sar=s.split(" ");
				
				for(int i=0;i<sar.length;i++) {
					String rev=" ";
					for(int j=0;j<sar[i].length();j++) {
						rev=sar[i].charAt(j)+rev;
						
					}
					res=res+rev+" ";
				}
		System.out.println(res);
	}

}
