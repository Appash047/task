package string;

public class Palidrom {

	public static void main(String[] args) {

		
		String s="ab12321baikjjk2324";
		int count=0;
		for(int i=0;i<s.length();i++) {
			for(int j=1;i<s.length();j++) {
				if(i==j) {
					count++;
				}
				
			}
		}
		System.out.println(count);
	}

}
