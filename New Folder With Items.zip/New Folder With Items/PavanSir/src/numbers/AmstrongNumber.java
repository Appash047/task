package numbers;

public class AmstrongNumber {

	public static void main(String[] args) {

		
	}

}
