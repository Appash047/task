package string01;

public class ToLowerCase {

	public static void main(String[] args) {

		String name="Appasha";
		System.out.println(name.toLowerCase());
	}

}
