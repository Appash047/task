package string01;

public class IsUpperCase {

	public static void main(String[] args) {

		String name="Poojari Appasha";
		for(int i=0;i<name.length();i++) {
			char c=name.charAt(i);
			
			if(Character.isUpperCase(c)) {
			System.out.print(c);
			}
		}
	}

}
