package string01;

public class IsLowerCase {

	public static void main(String[] args) {

		String name="Appash Poojari";
		for(int i=0;i<name.length();i++) {
			char c=name.charAt(i);
			if(Character.isLowerCase(c)) {
				System.out.println(c);
			}
		}
	}

}
