package string01;

public class ReversString {

	public static void main(String[] args) {

		String rev="";
		String name="Appasha";
		for(int i=0;i<name.length();i++) {
			char c=name.charAt(i);
			if(Character.isLetter(c)) {
				rev=c+rev;
			}
		}
		System.out.println(rev);
	}

}
