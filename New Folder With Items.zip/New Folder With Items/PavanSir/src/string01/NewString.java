package string01;

public class NewString {

	public static void main(String[] args) {

		String name="Appasha Poojari";
		String sn="";
		for(int i=0;i<name.length();i++) {
			char c=name.charAt(i);
			if(Character.isUpperCase(c)) {
				sn=sn+c;
				
			}
		}
		System.out.println(sn);

	}

}
