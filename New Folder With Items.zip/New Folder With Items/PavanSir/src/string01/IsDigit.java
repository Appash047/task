package string01;

public class IsDigit {

	public static void main(String[] args) {

		String name="Appasha 047";
		for(int i=0;i<name.length();i++) {
			char c=name.charAt(i);
			if(Character.isDigit(c)) {
				System.out.println(c);
			}
		}
	}

}
