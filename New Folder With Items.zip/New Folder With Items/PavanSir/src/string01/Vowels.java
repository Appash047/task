package string01;

public class Vowels {

	public static void main(String[] args) {

		String name="Appasha Poojari";
		for(int i=0;i<name.length();i++) {
			char c=name.charAt(i);
			
			if(c=='A' || c=='E' || c=='I' || c=='O' || c=='U') {
				System.out.println("Vowels  :  --->" +c);
			}
		}
	}

}
