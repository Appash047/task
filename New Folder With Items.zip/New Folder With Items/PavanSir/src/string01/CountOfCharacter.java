package string01;

public class CountOfCharacter {

	public static void main(String[] args) {
		int count1 = 0;
		String name = "Appasha Poojari";
		for (int i = 0; i < name.length(); i++) {
			char c = name.charAt(i);
//			count1++;
			if (Character.isUpperCase(c)) {
//				count1++;
			}
			if(Character.isLowerCase(c)) {
//				count1++;
			}
		}
		System.out.println(count1);
	}

}
