package string01;

public class ToUpperCase {

	public static void main(String[] args) {

		String name="Appasha";
		System.out.println(name.toUpperCase());
	}

}
