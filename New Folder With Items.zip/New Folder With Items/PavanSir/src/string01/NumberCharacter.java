package string01;

public class NumberCharacter {

	public static void main(String[] args) {

		String number="";
		String str="";
		String name="Appasha 047";
		for(int i=0;i<name.length();i++) {
			char c=name.charAt(i);
			if(Character.isDigit(c)) {
				number=number+c;
			}else {
				str=str+c;
			}
			
		}
		System.out.println(number+str);
	}

}
