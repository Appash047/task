package com.jsp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jsp.dto.Person;
import com.jsp.service.PersonService;

@WebServlet("/login")
public class LoginPerson extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		String email=req.getParameter("email");
		String password=req.getParameter("password");
		
		Person person=new Person();
		person.setEmail(email);
		person.setPassword(password);
		
		PersonService personService=new PersonService();
        Person person2=personService.login(email, password);
		
		if (person2 != null) {
			req.setAttribute("keylogin", person2);
			RequestDispatcher requestDispatcher=req.getRequestDispatcher("login1.jsp");
			requestDispatcher.forward(req, resp);
		}else {
			RequestDispatcher requestDispatcher=req.getRequestDispatcher("Login.jsp");
			requestDispatcher.include(req, resp);
		}
	}

}
