package com.jsp.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jsp.dto.Person;
import com.jsp.service.PersonService;
@WebServlet("/create")
public class CreatePerson extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name=req.getParameter("name");
		String ageimp=req.getParameter("age");
		String email=req.getParameter("email");
		String password=req.getParameter("password");
		String phoneimp=req.getParameter("phone");
		
		Person Person=new Person();
		Person.setName(name);
		Person.setEmail(email);
		Person.setPassword(password);
		
		if(ageimp != "" && phoneimp != "") {
		Person.setAge(Integer.parseInt(ageimp));
		Person.setPhone(Long.parseLong(phoneimp));
		}
		else {
			Person.setAge(0);
			Person.setPhone(0);
		}
		
		PersonService PersonService=new PersonService();
		Person Person2=PersonService.createPerson(Person);
		
		if(Person2 != null) {
		
			RequestDispatcher requestDispatcher=req.getRequestDispatcher("Home.jsp");
			requestDispatcher.forward(req, resp);
		}
		else {
			RequestDispatcher requestDispatcher=req.getRequestDispatcher("Create.jsp");
			requestDispatcher.include(req, resp);
		}
		
	}

}
