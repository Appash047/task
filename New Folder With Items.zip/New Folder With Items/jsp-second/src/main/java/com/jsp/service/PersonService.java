package com.jsp.service;

import java.util.List;

import com.jsp.dao.PersonDao;
import com.jsp.dto.Person;

public class PersonService {

	PersonDao personDao = new PersonDao();

	public Person createPerson(Person person) {
		if (person.getName() != "" && person.getAge() != 0 && person.getEmail() != "" && person.getPassword() != ""
				&& person.getPhone() != 0) {
			return personDao.createPerson(person);
		}
		return null;
	}

	public Person updatePerson(Person person) {
		if (person.getName() != "" && person.getAge() != 0 && person.getEmail() != "" && person.getPassword() != ""
				&& person.getPhone() != 0) {
			return personDao.updatePerson(person);
		}
		return null;
	}

	public Person deletePerson(int id) {
		if (id != 0) {
			return personDao.deletePerson(id);
		}
		return null;
	}

	public Person findPerson(int id) {
		if (id != 0) {
			return personDao.findPerson(id);
		}
		return null;
	}

	public List<Person> displayAll() {
		return personDao.displayAll();
	}

	public Person login(String email, String password) {
		return personDao.login(email, password);
	}
}
