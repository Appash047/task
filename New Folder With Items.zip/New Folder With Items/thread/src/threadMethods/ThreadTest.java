package threadMethods;

public class ThreadTest {

	public static void main(String[] args) throws InterruptedException {

		T1 t1 = new T1();
		T2 t2 = new T2();
		System.out.println(t1.getState());
		t1.start();
		t1.sleep(5000);
		System.out.println(t1.getState());
		t2.start();
		for (int i = 1; i <= 10; i++) {
			System.out.println("main");
		}
		System.out.println(t1.isAlive());
		System.out.println("t1" + t1.getPriority());
		System.out.println("t2" + t2.getPriority());
		
		System.out.println(t1.getId());
		System.out.println(t1.getName());
		System.out.println();

	}

}
