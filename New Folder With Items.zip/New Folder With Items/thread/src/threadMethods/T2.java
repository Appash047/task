package threadMethods;

public class T2 extends Thread {
	public void run() {
		for (int i = 1; i <= 10; i++) {
			System.out.println("run T2");
		}
	}
}
