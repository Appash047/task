package executorService;

public class Demo1 extends Thread{
 

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("run");
	}

	public static void main(String[] args) {
		
		Thread t=new Thread();
		t.start();
		System.out.println("main");
		
	}
}
