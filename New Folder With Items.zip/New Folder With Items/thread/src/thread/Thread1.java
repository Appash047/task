package thread;

public class Thread1 extends Thread{
	
	public void run() {
		for(int i=1;i<=10;i++) {
			System.out.println("run");
		}
	}
	public static void main(String[] args) {
		Thread1 thread1=new Thread1();
		thread1.start();
		for(int i=1;i<=10;i++) {
			System.out.println("main");
		}
	}

}
