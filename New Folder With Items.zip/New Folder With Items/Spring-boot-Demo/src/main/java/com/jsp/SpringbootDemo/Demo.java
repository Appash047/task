package com.jsp.SpringbootDemo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Demo {

	@GetMapping("/test1")
	public String test1() {
		return "Hello";
	}

	@GetMapping("/test2")
	public Employee test2() {
		Employee employee = new Employee();
		employee.setId(1);
		employee.setName("appi");
		employee.setSal(1111.20);

		return employee;
	}

	@PostMapping("/test3")
	public String test3(@RequestBody Employee employee) {
		System.out.println(employee.getId() + " " + employee.getName() + " " + employee.getSal());
		return "data";
	}
}
