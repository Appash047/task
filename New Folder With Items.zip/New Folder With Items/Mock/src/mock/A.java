package mock;

public interface A {

	default void run() {
		System.out.println("this is A");
	}
}
