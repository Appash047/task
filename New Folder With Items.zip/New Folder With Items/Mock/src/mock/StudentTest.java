package mock;

import java.util.ArrayList;
import java.util.Scanner;

public class StudentTest {
	// Name = Appasha
		//Batch code= ACCE26
		// Mobile Number : 8688783502
		

	public static void main(String[] args) {
		ArrayList<Student> list = new ArrayList<>();

		System.out.println("Enter the object Size");
		Scanner sc = new Scanner(System.in);
		int s = sc.nextInt();
		for (int i = 0; i < s; i++) {
			System.out.println("Enter Student Details ");
			list.add(new Student(sc.nextInt(), sc.nextInt(), sc.next(), sc.nextDouble()));
		}
		System.out.println(list);

		for (Student student : list) {
		    int id = student.getId();
		    if (id % 2 == 0) {
		        System.out.println("Even ID: " + id);
		    }
		}

	}

}
