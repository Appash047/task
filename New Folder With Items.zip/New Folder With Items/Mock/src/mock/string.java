package mock;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class string {

	public static void main(String[] args) {
		// Name = Appasha
		//Batch code= ACCE26
		// Mobile Number : 8688783502
		

		String str[] = { "Ram", "Rohan", "Rajesh" };

		ArrayList<Character> al=new ArrayList<>();

		for (String s : str) {
			for (int i = 0; i < s.length(); i++) {
				char c = s.charAt(i);
				if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
					System.out.print(c+",");
					al.add(c);

				}
			}
		}
		System.out.println(al);
		
		LinkedList<Character> l=new LinkedList<>(al);
		System.out.println(l);

		Collections.sort(l); // sort the vowels in ascending order

		    System.out.println(l);

	}
}

