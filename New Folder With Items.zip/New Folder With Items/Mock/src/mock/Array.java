package mock;

public class Array {

	public static void main(String[] args) {
		// Name = Appasha
		//Batch code= ACCE26
		// Mobile Number : 8688783502
		
		        int a[] = { 5, 3, 8, 6, 1, 3, 2 };
		        int sum = 0;
		        int num=0;
		        for (int i = 0; i < a.length; i++) {
		            sum += a[i];
		            if (num <= 1) {
			        }
			        for (int j = 2; j <= Math.sqrt(num); j++) {
			            if (num % j == 0) {
			            }
			        }
		        }
		        System.out.println("Sum of the array elements: " + sum);

		    }
}

