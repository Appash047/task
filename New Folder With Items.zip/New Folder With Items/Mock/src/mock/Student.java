package mock;

public class Student implements Comparable<Student> {

	
	// Name = Appasha
		//Batch code= ACCE26
		// Mobile Number : 8688783502
		
	
	private int id;
	private int age;
	private java.lang.String name;
	private double marks;

	public Student(int id, int age, java.lang.String name, double marks) {
		super();
		this.id = id;
		this.age = age;
		this.name = name;
		this.marks = marks;
	}

	@Override
	public java.lang.String toString() {
		return "Student   [id=" + id + ",    age=" + age + ",    name=" + name + ",       marks=" + marks + " ]";

	}

	public int compareTo(Student student) {
//		return (int) (this.marks - student.marks);
		return this.id-student.id;
//		return this.name-student.name;
		
	}

	public int getId() {
		// TODO Auto-generated method stub
		return 0;
	}

}
