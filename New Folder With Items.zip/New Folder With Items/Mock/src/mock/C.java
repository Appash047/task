package mock;

public class C implements A,B {

	@Override
	public void run() {
		System.out.println("this is C");
	}
	public static void main(String[] args) {
		C c=new C();
		c.run();
		A.run();
	}
	

}
