package mock;

public interface B {
	default void run() {
		System.out.println("this is B");
	}
}
