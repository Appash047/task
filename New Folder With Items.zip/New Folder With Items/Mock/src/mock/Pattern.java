package mock;

public class Pattern {

	public static void main(String[] args) {

		// Name = Appasha
		//Batch code= ACCE26
		// Mobile Number : 8688783502
		
		char c='a';
		for(int i=1;i<=5;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print(" ");
			}
			for(int k=5;k>=i;k--) {
				System.out.print(" "+i);
			}
			System.out.println();
		}
		for(int i=1;i<=4;i++) {
			for(int j=3;j>=i;j--) {
				System.out.print(" ");
			}
			for(int k=1;k<=i;k++) {
				System.out.print(" "+c);
				c++;
			}
			System.out.println();
		}
	}
}