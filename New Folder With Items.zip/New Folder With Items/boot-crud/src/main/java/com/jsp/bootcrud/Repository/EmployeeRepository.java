package com.jsp.bootcrud.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.bootcrud.Dto.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

}
