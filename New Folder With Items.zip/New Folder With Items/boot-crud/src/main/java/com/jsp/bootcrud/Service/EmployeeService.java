package com.jsp.bootcrud.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jsp.bootcrud.Dao.EmployeeDao;
import com.jsp.bootcrud.Dto.Employee;

@Service
public class EmployeeService {

	@Autowired
	EmployeeDao dao;

	public Employee save(Employee employee) {
		return dao.save(employee);
	}

	public List<Employee> display() {
		return dao.display();
	}

	public Employee find(int id) {
		return dao.find(id);
	}

	public String delete(int id) {
		return dao.delete(id);
	}

	public Employee update(Employee employee) {
		return dao.update(employee);
	}
}
