package list;

import java.util.Collection;
import java.util.Collections;

public class LinkedList {

	public static void main(String[] args) {

	}

}
