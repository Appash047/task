package list;

import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ArrayList {

	public static void main(String[] args) {

		List l=new  java.util.ArrayList<>();
		l.add('a');
		l.add("appi");
		l.add(23);
		l.add(1, "appu");
		System.out.println(l);
		
		List ll=new  java.util.ArrayList<>();
		ll.add('a');
		ll.add("appi");
		ll.add(23);
		ll.add(1, "appu");
		
	 Iterator itr=	l.iterator();
	 while(itr.hasNext()) {
		 System.out.println(itr.next());
	 }
	 
	 ListIterator litr=l.listIterator();
	 while(litr.hasNext()) {
		 System.out.println(litr.next());
	 }
	 while(litr.hasPrevious()) {
		 System.out.println(litr.previous());
	 }
	 

	 
	}

}
