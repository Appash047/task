package com.jsp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo {

	public static void main(String[] args) {
		
		//Load the driver
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			
			
			// Establish the connection
			
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/emp2,user=root,password=88888888");
			System.out.println(connection);
			
			//Establish the statement
			Statement statement=connection.createStatement();
			System.out.println(statement);
			
//			statement.execute("create table emp(id int(2) primary key,Name varchar(20) not null,age int(2) not null);");
			
//			statement.execute("insert into emp values(24,'Malli',30);");
			
			statement.execute("insert into emp values(24,'Malli',30);");
			
			connection.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
