package com.jsp;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class ExProperties {

	public static void main(String[] args) {
		Properties  properties=new Properties();
		
		
		
		try {
			FileInputStream fileInputStream=new FileInputStream("dbconfig.properties");
			properties.load(fileInputStream);
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			
//			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "88888888");
//			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306,root,88888888");
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306", properties);

			
			Statement statement=connection.createStatement();
			statement.execute("create database jdbc_crud");
//			
//			PreparedStatement preparedStatement= connection.prepareStatement("delete from user where id=?");
//			
//			preparedStatement.setInt(1, 2);
//			preparedStatement.executeUpdate();
			
			
			
		
			connection.close();
			
			System.out.println("database created");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}

}
