package com.jsp;
//
//import java.io.FileInputStream;
//import java.sql.CallableStatement;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.Statement;
//import java.util.Properties;
//
//import com.mysql.cj.jdbc.Driver;

public class Demo2 {

	public static void main(String[] args) {

//		Properties properties=new Properties();

		try {

//		FileInputStream fileInputStream=new FileInputStream("dbconfig.properties");
//		properties.load(fileInputStream);

			Class.forName("com.mysql.cj.jdbc.Driver");
//		DriverManager.registerDriver(new Driver());

//			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "88888888");
//		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306 ? User=root & Password=88888888");
//		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306", properties);

//		Statement statement=connection.createStatement()	
//		PreparedStatement preparedStatement = connection.prepareStatement("id=?");
//		preparedStatement.setInt(1,24);
//			CallableStatement callableStatement=connection.

		} catch (Exception e) {
			System.out.println(e);
		}

	}
}
