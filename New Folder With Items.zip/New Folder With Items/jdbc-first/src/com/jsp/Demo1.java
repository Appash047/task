package com.jsp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.jdbc.Driver;

public class Demo1 {

	public static void main(String[] args) {

	try {
		DriverManager.registerDriver(new Driver());
		
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "88888888");
		
		Statement statement=connection.createStatement();
		
		statement.execute("create database emp");
		
		connection.close();
		
		System.out.println("database created");
		} 
	catch (SQLException e) {

		e.printStackTrace();
	}
		
	}

}
