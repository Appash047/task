package com.jsp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.jsp.dao.EmployeeDao;
import com.jsp.dto.Employee;

@Component
public class EmployeeService {

	@Autowired
	EmployeeDao dao;

	public Employee saveEmployee(Employee employee) {
		return dao.saveEmployee(employee);
	}

	public Employee updateEmployee(Employee employee) {
		return dao.upodateEmployee(employee);
	}
	public Employee deleteEmployee(int id) {
		return dao.deleteEmployee(id);
	}
	public Employee getById(int id) {
		return dao.getById(id);
	}
	public List<Employee> getAll(){
		return dao.getAll();
	}

}
