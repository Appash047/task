
package sumOfLCM_GCD;

import java.util.Scanner;

public class LCM {
	public static int lcm(int a, int b) {
		int max = (a > b) ? a : b;
		int lcm = max, k = 2;
		while (true) {
			if (lcm % a == 0 && lcm % b == 0) {
				return lcm;
			}
			lcm = max * k++;

		}
	}

	public static int gcd(int a, int b) {
		int min = (a > b) ? b : a;
		for (int i = min; i >= 1; i--) {
			if (a % i == 0 && b % i == 0) {
				return i;
			}

		}
		return 1;
	}

	public static void main(String[] args) {

		
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		System.out.println(lcm(a,b)+gcd(a,b));
	}

}
