package abstraction;

public abstract class Television {
	abstract public void volume();
	abstract public void scanner();
	abstract public void camera();
	public void onoff() {
		System.out.println("onoff");
	}

}
