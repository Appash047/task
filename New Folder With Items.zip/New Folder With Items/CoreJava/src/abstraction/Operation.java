package abstraction;

public interface Operation {

	void sum();

	void sub();

	void mult();

	//in java 8 we can defind 
	default void div() {
		System.out.println("div");

	}
	//in java 8 we can defind 
	static void mod() {
		System.out.println("mod");
	}
}
