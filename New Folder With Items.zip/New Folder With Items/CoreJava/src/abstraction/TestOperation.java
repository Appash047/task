package abstraction;

public class TestOperation implements Operation {

	public void sum() {
		System.out.println("sum");
	}
	
	public void sub() {
		System.out.println("sub");
	}
	
	public void mult() {
		System.out.println("mult");
	}

	public static void main(String[] args) {

	}

}
