package abstraction;

public class SmartTV extends Television {

	public void volume() {
		System.out.println("volume");
	}

	public void scanner() {
		System.out.println("volume");

	}

	public void camera() {
		System.out.println("volume");

	}

	public static void main(String[] args) {
		SmartTV tv = new SmartTV();
		tv.camera();

		Television tv1 = new SmartTV();

		tv1.onoff();

	}

}
