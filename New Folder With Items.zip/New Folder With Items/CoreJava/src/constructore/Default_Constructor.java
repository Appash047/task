package constructore;

public class Default_Constructor {

	String name;
	int id;

	public static void main(String[] args) {
		
		Default_Constructor d1=new Default_Constructor();
		System.out.println(d1.name+"  "+d1.id);
		
		
	}

}
