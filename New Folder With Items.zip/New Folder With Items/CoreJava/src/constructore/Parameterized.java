package constructore;

public class Parameterized {
	String name;
	int id;
	
	Parameterized(String name, int id)
	{ 
		this.name=name;
	    this.id=id;
	}
	
	public static void main(String[] args) {
		
		Parameterized e1=new Parameterized("deepak", 101);
		Parameterized e2=new Parameterized("abc", 102); 
		
	    System.out.println("Employee 1 :"+e1.name+" "+e1.id);
	    System.out.println("Employee 2 :"+e2.name+" "+e2.id);
	}

}

