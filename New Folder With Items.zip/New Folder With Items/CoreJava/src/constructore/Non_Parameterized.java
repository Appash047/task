package constructore;

public class Non_Parameterized {
	
	Non_Parameterized()
	{
		System.out.println("no arg constructor");
	}
	
	

	public static void main(String[] args) {
		
		Non_Parameterized p1=new Non_Parameterized();
		System.out.println(p1);
		
	}

}
