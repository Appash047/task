package loops;

public class ForLoop {
	public static void main(String[] args) {
		
		int a =5;
		for(int i=0;i<a;i++) {
			System.out.println("Hello");
		}
		for(int i=1;i<a;i++) {
			System.out.println("Hi");
		}
		
		System.out.println("*******************");
		
//		int b=5;
//		int j=0;
//		while(j<b) {
//			System.out.println("Appi");
//			j++;
//		}
	
		
		  int i=1;    
		    do{    
		        System.out.println(i);    
		    i++;    
		    }while(i<=10);    
		
		
		
	}
	}

