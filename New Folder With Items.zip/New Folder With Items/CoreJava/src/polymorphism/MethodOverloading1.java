package polymorphism;

public class MethodOverloading1 {
	
	void show(int a)
	{
		System.out.println("int method "+a);
	}
	void show(int... a)// vararg 
	{
		System.out.println("multiple int "+a);
	}

	public static void main(String[] args) {
		MethodOverloading1 m=new MethodOverloading1();
		m.show(10);
		m.show(10,20,30);
		
		
	}

}
