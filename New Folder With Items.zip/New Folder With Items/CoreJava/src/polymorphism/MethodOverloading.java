package polymorphism;

public class MethodOverloading {
	
	void show() {
		System.out.println("no arg");
	}
	void show(int id) {
		System.out.println("id");
	}

	public static void main(String[] args) {
		MethodOverloading m=new MethodOverloading();
		m.show();
		m.show(12);
		
		
	}

}
