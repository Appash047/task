package statements;

public class IfCondition {

	public static void main(String[] args) {

		int a=10;
		int b=20;
		//if
		if(a>b) {
			System.out.println(a+" is greter than "+b);
		}
		
		
		//if else
		if(a>b) {
			System.out.println(a+" is greter than "+b);
		}
		else {
			System.out.println(a+" is not greter than "+b);
		}
		
		
		//if else if
		if(a>b) {
			System.out.println(a+" is greter than "+b);
		}
		else if(b==a) {
			System.out.println(a+" is not Equel than "+b);
		}
		else {
			System.out.println(a+" is not greter than "+b);
		}
		
		
		//nested if
		if(a>0) {
			if(a>b) {
				System.out.println(a+" is greter than "+b);
			}
			else {
				System.out.println(a+" is not greter than "+b);
			}
		}
		
	}

}
