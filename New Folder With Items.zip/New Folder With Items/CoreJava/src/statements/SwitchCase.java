package statements;

public class SwitchCase {

	public static void main(String[] args) {

		int option=4;
		
		switch(option) {
		
		case 1 :System.out.println("01");
		break;
		
		case 2 :System.out.println("02");
		break;
		
		case 3 :System.out.println("03");
		break;
		
		case 4 :System.out.println("04");
		break;
		
		case 5 :System.out.println("05");
		break;
		
		default : System.out.println("default");
		
		}
	}

}
