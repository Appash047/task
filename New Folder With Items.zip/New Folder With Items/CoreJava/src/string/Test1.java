package string;

public class Test1 {

	public static void main(String[] args) {

		int ar[]= {5,3,1,2,3,1,4,6,3,2,4};
		for(int i=0;i<=ar.length;i++) {
			
		}
	}

}
