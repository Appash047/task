package string;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {

//		Scanner sc = new Scanner(System.in);
//		int x = sc.nextInt();
//		int y = sc.nextInt();
//
//		int c = x / y;
//		System.out.println(c);
//		sc.close();
//		
		
//		
//		String s=new String("hello");
//		String s1=new String("Hello");
//		System.out.println(s.equals(s1));
//		System.out.println(s.equalsIgnoreCase(s1));
//		System.out.println(s.compareTo(s1));
//		System.out.println(s.compareToIgnoreCase(s1));
//		
		
		
//		

		
//		String s="Appasha";
//		System.out.println(s.indexOf('a'));
//		System.out.println(s.indexOf("as"));
//		System.out.println(s.lastIndexOf('a'));
//		System.out.println(s.startsWith("A"));
//		System.out.println(s.endsWith("h"));
//		System.out.println(s.contains("a"));
//		System.out.println(s.charAt(3));
		
		
//		
//		String s="this is demo";
//		System.out.println(s.substring(3));
//		System.out.println(s.subSequence(3, 9));
//		System.out.println(s.substring(3, 9));
		
		
//		String name="Appasha";
//		System.out.println(name);
//		char[] c=name.toCharArray();
//		System.out.println(c);
//		
//		System.out.println(name.toLowerCase());
//		System.out.println(name.toUpperCase());
//		System.out.println(name.toString());
		
		int a=10 ,b=20;
		String s=String.valueOf(a);
		String s1=String.valueOf(b);
		System.out.println(s+s1);
		System.out.println(a+b);
		System.out.println();
	}

}
