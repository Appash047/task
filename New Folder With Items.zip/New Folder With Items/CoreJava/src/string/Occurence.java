package string;

import array.Array;

public class Occurence {

	public static void main(String[] args) {

		String s = "aabbbcccc";
		int a1 = 0;
		int b1 = 0;
		int c1 = 0;

		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == 'a') {
				a1++;
			} else if (s.charAt(i) == 'b') {
				b1++;
			} else if (s.charAt(i) == 'c') {
				c1++;
			}
		}
		System.out.println(a1);
		System.out.println(b1);
		System.out.println(c1);

	}

}
