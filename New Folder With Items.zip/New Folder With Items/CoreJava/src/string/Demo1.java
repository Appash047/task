package string;

public class Demo1 {

	public static void main(String[] args) {

		String s1="Appi"; //String literal
		
		String s2=new String("Appi");// String Object
		
		System.out.println(s1);
		System.out.println(s2);
		
		String s3=" Appash ";
		String s4=" Poojari ";
		
		//Concatenation
		System.out.println(s3.concat(s4));
		System.out.println(s3+s4);
		
		//Upper case
		System.out.println(s3.toUpperCase());
		
		//lower case
		System.out.println(s4.toLowerCase());
		
		//length
		System.out.println(s3.length());
		
		//Equals to
		System.out.println(s3.equals(s4));// compare the array data
		
		//equals avoid upper lower
		System.out.println(s3.equalsIgnoreCase(s4));
		
		//== Operate
		System.out.println(s3==s4);// compare the address
		
		//start printing with index number
		System.out.println(s3.substring(3));
		
		//start print index between
		System.out.println(s3.substring(0, 3));
		
		//trim the start and end space
		System.out.println(s3.trim());
		
		System.out.println(s3.isBlank());
		System.out.println(s3.isEmpty());
		System.out.println(s3.charAt(3));
		System.out.println(s3.hashCode());
		System.out.println(s3.repeat(0));
		System.out.println(s3.toString());
		
		
		System.out.println("**********");
		String s="Appi";
		String ss="Appi";
		System.out.println(s==ss); //String literal 
		System.out.println(s.equals(ss));
	}

}
