package string;

public class Demo {

	public static void main(String[] args) {

		String s = new String("Hello");
		System.out.println(s);
		s = "h1";
		System.out.println(s);
		System.out.println(s);
		

	}

}
