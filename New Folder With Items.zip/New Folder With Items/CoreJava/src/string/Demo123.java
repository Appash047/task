package string;

import java.util.LinkedList;
import java.util.List;

public class Demo123 {

	public static void main(String[] args) {

		String s="this is a java programming class";
		String res="";
		
		
		for(int i=0;i<=s.length()-1;i++) {
			if(s.charAt(i)=='a' || s.charAt(i)=='e'|| s.charAt(i)=='i' || s.charAt(i)=='o' || s.charAt(i)=='u'){
				res = res + s.charAt(i);
			}
		}
		System.out.println(res);
				

		
	}

}
