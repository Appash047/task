package string;

public class ResversString {

	public static void main(String[] args) {

		String s=new String("Appasha");
		System.out.println(s);
		
		String res="";
		for(int i=0;i<s.length();i++) {
			res=s.charAt(i)+res;
		}
		System.out.println(res);
		
		String res1="";
		for(int i=s.length()-1;i>=0;i--) {
			res1=res1+s.charAt(i);
		}
		System.out.println(res1);
	}

}
