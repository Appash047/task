package patterns;

public class Demo17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
