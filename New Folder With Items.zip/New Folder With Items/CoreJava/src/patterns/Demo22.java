package patterns;

public class Demo22 {
public static void main(String[] args) {
	for(int i=1;i<=4;i++) {
		for(int j=4;j>=i;j--) {
			System.out.print(" ");
		}
		for(int k=1;k<=i;k++) {
			System.out.print(i+" ");
		}
		System.out.println();
	}
	
	
	
	for(int i=1;i<=4;i++) {
		for(int j=4;j>=i;j--) {
			System.out.print(" ");
		}
		for(int k=1;k<=i;k++) {
			System.out.print(k+" ");
		}
		System.out.println();
	}
	
	
	int num=1;
	for(int i=1;i<=4;i++) {
		for(int j=4;j>=i;j--) {
			System.out.print(" ");
		}
		for(int k=1;k<=i;k++,num++) {
			System.out.print(num+" ");
		}
		System.out.println();
	}
}
}
