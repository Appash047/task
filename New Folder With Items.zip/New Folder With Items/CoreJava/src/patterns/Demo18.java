package patterns;

public class Demo18 {

	public static void main(String[] args) {

		char ch = 'A';
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(ch + " ");
			}
			System.out.println();
		}
		System.out.println("\n****************\n");
	
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(ch + " ");
			}
			System.out.println();
			ch++;
		}
		System.out.println("\n****************\n");

		ch='A';
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(ch + " ");
				ch++;
			}
			System.out.println();
		}
		System.out.println("\n****************\n");

		for (int i = 1; i <= 5; i++) {
			ch='A';
			for (int j = 1; j <= i; j++) {
				System.out.print(ch + " ");
				ch++;
			}
			System.out.println();
		}
		System.out.println("\n****************\n");

	}

}
