package exception;

import java.io.FileNotFoundException;

public class Throws_Test {

	public static void main(String[] args) {

		Throws_ReadWrite throws_ReadWrite=new Throws_ReadWrite();
		try {
			throws_ReadWrite.readFile();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			throws_ReadWrite.writeFile();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("hello");
		}

}
