package exception;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class Throws_ReadWrite {
void readFile() throws FileNotFoundException
{
	FileInputStream fileInputStream=new FileInputStream("d:/xyz.txt");
}

void writeFile() throws FileNotFoundException
{
	String text="hello";
	FileOutputStream fileOutputStream=new FileOutputStream("desktop");
	
}
	
	
}
