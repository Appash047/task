package exception;

public class Throw_AgeException extends RuntimeException {

	Throw_AgeException(String msg){
		super(msg);
	}
}
