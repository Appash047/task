package exception;

public class Demo {
	public static void main(String[] args) {

		System.out.println("Hello 01");
		System.out.println("Hello 02");
		System.out.println("Hello 03");

		// checked exception
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
		System.out.println(e);
		}

		// unchecked exception
		String s = null;
		try {
			System.out.println(s.length());
		} catch (Exception e) {
			System.out.println(e);
		}
		
		int a[]= {10,20,30};
		System.out.println(a[1]);
		try {
		System.out.println(a[10]);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally{
			System.out.println("finally");
		}
		
		int aa=10;
		int bb=0;
		try {
		System.out.println(aa/bb);
		}
		catch(Exception e) {
			e.printStackTrace();
		}

		System.out.println("Hello 04");
		System.out.println("Hello 05");
		System.out.println("Hello 06");

	}

}
