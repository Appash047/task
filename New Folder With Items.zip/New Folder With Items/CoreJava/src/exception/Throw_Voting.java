package exception;

import java.util.Scanner;

public class Throw_Voting {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.print("enter ur age  :");
		int age = sc.nextInt();
		sc.close();
		//try {
			if (age < 18) {
				throw new Throw_AgeException("u r not eligible");
			}

			else {
				System.out.println("voted");
			}
			
	//	} catch (Exception e) {
		//	e.printStackTrace();

	//	}
		System.out.println("Hello");
	}

}
