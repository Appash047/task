package method;

public class Demo {

	// static variable
	static String org = "jsp";

	// non static variable
	int id = 10;

	// static method
	static void java() {
		System.out.println("java");
	}

	// non static method
	void javaLecture() {
		System.out.println("jagannath");
	}

	// parameter method
	void student(int id) {
		System.out.println("student id is : " + id);

	}

	public static void main(String args[]) {

		Demo demo = new Demo();
		
		System.out.println(org);
		System.out.println(demo.id);
		java();
		demo.javaLecture();
		demo.student(24);
	}
}
