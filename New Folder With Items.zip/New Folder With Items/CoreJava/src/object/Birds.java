package object;

public class Birds {
	
	 void fly()
	{
		System.out.println("I am flying");
	}
	 public static void main(String[] args) {
		
			Birds sp=new Birds();
			sp.fly();
			
			Animal obj=new Animal();
			System.out.println(obj); //object.Animal@7e774085
			obj.cat();
			obj.dog();
			
	}

}
