package object;

public class CarDrive {

	public static void main(String[] args) {

		Car obj=new Car("appi",20.0);
		System.out.println(obj);
		System.out.println(obj.toString());
		
	}

}


String