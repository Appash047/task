package object;

public class Demo {

	int id;
	String name;
	
	
	@Override
	public String toString() {
		return "Demo [id=" + id + ", name=" + name + "]";
	}
	
	
}
