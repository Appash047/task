package object;

public class Demo2 {
	
	String color;
	int age;
	void intobj(String c,int a)
	{
		color=c;
		age=a;
	}
	void display()
	{
		System.out.println(color+" "+age);
	}

	public static void main(String[] args) {
		
		Demo2 d2=new Demo2();
		d2.intobj("red", 22);
		d2.display();
		
		
	}

}
