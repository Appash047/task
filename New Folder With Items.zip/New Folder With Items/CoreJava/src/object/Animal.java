package object;

public class Animal {
	public void cat()
	{
		System.out.println("Cat is sleeeping");
	}
	public void dog() {
		System.out.println("Dog is barking");
	}
	
	public static void main(String[] args) {
		// Object created by using new keyword
		//we can also print the object refference number which is in hexa number
		Animal obj=new Animal();
		System.out.println(obj); //object.Animal@7e774085
		obj.cat();
		obj.dog();
		
	
		
		
		
	}

}



