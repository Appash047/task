package object;

public class Car {

	String name;
	double speed;
	
	public Car(String name,double speed) {
		super();
		this.name=name;
		this.speed=speed;
		
	}

	@Override
	public String toString() {
		return "Car [name=" + name + ", speed=" + speed + "]";
	}
	
}
