package object;

public class demo1 {
	
	String color;
	int age;
	

	public static void main(String[] args) {
		demo1 d1 =new demo1();
		d1.color="red";
		d1.age=22;
		
		System.out.println(d1.age+" "+d1.color);
	
		
	}

}
