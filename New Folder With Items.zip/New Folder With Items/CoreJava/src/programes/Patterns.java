package programes;

public class Patterns {

	public static void main(String[] args) {

//		for(int i=0;i<4;i++) {
//			for(int j=0;j<5;j++) {
//				System.out.print("*"+" ");
//			}
//			System.out.println("");
//		}
//		
//		for(int i=0;i<=4;i++) {
//			for(int j=0;j<i;j++) {
//				System.out.print("*"+" ");
//			}
//			System.out.println("");
//		}
//
//		for(int i=0;i<=4;i++) {
//			for(int j=0;j<i;j++) {
//				System.out.print(i+" ");
//			}
//			System.out.println("");
//		}
		int temp1=1;
		int temp2=1;
		for(int i=2;i<=2;i--) {
			for(int j=i;j>=0;j--) 
			{
				if(i>=temp1)
				{
				System.out.print(j);
				}
				else
				{
				System.out.print(" ");
				}
				temp1++;
			}
			for(int k=i;k<=0;k++)
			{
				if(i>=temp2)
				{
				System.out.print(k);
				}
				else
				{
				System.out.print(" ");
				}
				temp2++;
			}
			}
			System.out.println();
		}
}
		