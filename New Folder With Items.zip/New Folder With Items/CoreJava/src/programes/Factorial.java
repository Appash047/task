package programes;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {

		int first=1,number;
		System.out.println("Enter a number");
		Scanner s=new Scanner(System.in);
		number=s.nextInt();
		s.close();
		for(int i=1;i<number+1;i++) {
			first=first*i;
			
		}
		System.out.println("the factorial of "+number+" is a : "+first);
	}

}
