package programes;

import java.util.Scanner;

public class Armstrong {

	public static int count(int n) {
		int c = 0;
		while (n != 0) {
			c++;
			n = n / 10;
		}
		return c;
	}

	// ********************************************

	public static int power(int a, int b) {
		int pow = 1;
		for (int i = 1; i <= b; i++) {
			pow = pow * a;
		}
		return pow;
	}
	// ********************************************

	public static boolean checkArmstrong(int n) {
		int sum = 0;
		int temp = n;
		int c = count(n);
		while (n != 0) {
			int r = n % 10;
			sum = sum + power(r, c);
			n = n / 10;
		}
		if (temp == sum) {
			return true;
		} else {
			return false;
		}
	}
	// ********************************************

//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter the Number");
//		int n=sc.nextInt();
//		sc.close();
//		if(checkArmstrong(n)) {
//			System.out.println(n+" is the Armstrong number");
//		}
//		else {
//			System.out.println(n+" is not a Armstrong number");
//		}
//	}

	// ******************* Armstrong number m to n *************************

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter n the Number");
		int n = sc.nextInt();
		System.out.println("Enter m the Number");
		int m = sc.nextInt();
		sc.close();
		for (int i = n; i <= m; i++) {
			if (checkArmstrong(i)) {
				System.out.println(i);
			}
		}
	}
}
