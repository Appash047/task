package programes;

import java.util.Scanner;

public class String_Reverse {

	public static void main(String[] args) {

		String string;
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the String to reverse");
		string = s.nextLine();
		s.close();
		int len = string.length();
		String rev = " ";
		for (int i = len - 1; i > 0; i--) {
			rev = rev + string.charAt(i);
		}
		System.out.println(rev);

	}
}
