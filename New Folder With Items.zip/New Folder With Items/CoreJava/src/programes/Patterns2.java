package programes;

public class Patterns2 {

	public static void main(String[] args) {

		int size = 0;
		System.out.println();
		size = 5;
		int i, j, k;
		for (i = 0; i < size + 1; i++) {
			for (j = size; j > i; j--) {
				System.out.print(" ");
			}
			for (k = 0; k < (2 * i - 1); k++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("\n____________________\n");
		int ii, jj;
		int n = 6;
		for (ii = n; ii > 0; ii--) {
			for (jj = 0; jj < ii; jj++) {
				System.out.print("*");
			}
			System.out.println("");
		}
	}

}
