package array;

public class Anonymous_Array {

static void sum(int[] no) {
		
		int total=0;
		for(int i:no) {
			total=total+i;
		}
		System.out.println(total);
	}
	public static void main(String[] args) {

		Anonymous_Array.sum(new int[] {10,20,30});
		
		
		
	}

}
