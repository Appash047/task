package array;

public class Dem {

	public static void main(String[] args) {

		// 1-D Array
		int[] a = { 10, 20, 30 };
		System.out.println(a);
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " ");
		}
		System.out.println("\n*************");
		int[] b = new int[3];
		b[0] = 10;
		b[1] = 20;
		b[2] = 30;
		System.out.println(b);
		for (int i : b) {
			System.out.print(i + " ");
		}
		System.out.println("\n*************");

		// 2-D Array
		int[][] aa = { { 10, 20, 30 }, { 40, 50, 60 } };
		System.out.println(aa);
		for (int i = 0; i < aa.length; i++) {
			for (int j = 0; j < aa[i].length; j++) {
				System.out.print(aa[i][j] + " ");
			}
			System.out.println(" ");
		}

		System.out.println("\n*************");

		int[][] bb = new int[2][3];
		bb[0][0] = 10;
		bb[0][1] = 20;
		bb[0][2] = 30;
		bb[1][0] = 40;
		bb[1][1] = 50;
		bb[1][2] = 60;

		System.out.println(bb);
		for (int i = 0; i < bb.length; i++) {
			for (int j = 0; j < bb[i].length; j++) {
				System.out.print(bb[i][j] + " ");
			}
			System.out.println(" ");

		}

		System.out.println("\n*************");
		// 3-D Array
		String[][][] name = { { { "Appi", "Appu" }, { "Malli", "Mallu" } },
				{ { "Sujji", "Sujju" }, { "sakki", "Sukku" } } };
		System.out.println(name);
		for (int i = 0; i < name.length; i++) {
			for (int j = 0; j < name[i].length; j++) {
				for (int k = 0; k < name[i][j].length; k++) {
					System.out.print(name[i][j][k] + " ");
				}
				System.out.println(" ");
			}
		}

	}

}
