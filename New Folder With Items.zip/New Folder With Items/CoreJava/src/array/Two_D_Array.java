package array;

public class Two_D_Array {

	public static void main(String[] args) {

		int[][] a=new int[2][3];//matrix array
		a[0][0]=10;
		a[0][1]=20;
		a[1][1]=30;
//		System.out.println(a);
		System.out.println(a[0][0]);
		System.out.println(a[0][1]);
		System.out.println("\n****************\n");
		
		
		
		int[][] b={{10,20,30},{40,50}};
		
		
		for(int i=0;i<b.length;i++) {
			for(int j=0;j<b[i].length;j++) {
				System.out.print(b[i][j]+" ");
			}
			System.out.println();
		}
		
	}

}
