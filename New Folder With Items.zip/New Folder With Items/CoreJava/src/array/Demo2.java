package array;

public class Demo2 {
	static void printArray(int arr[]){  
		for(int i=0;i<arr.length;i++)  
		System.out.println(arr[i]);  
		}  
	public static void main(String[] args) {
//		int arr[] = { 50, 60, 70, 80 };
//		for (int i = 0; i <= arr.length; i++) {
//			System.out.println(arr[i]);
//		}

		
		printArray(new int[]{10,22,44,66});//passing anonymous array to method  
	}
}
