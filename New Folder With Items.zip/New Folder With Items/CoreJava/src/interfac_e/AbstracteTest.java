package interfac_e;

public abstract class AbstracteTest extends Abstraction{

	
	public static void main(String[] args) {
		
		Abstraction_2 a=new Abstraction_2();
		a.show();
	}
}

