package interfac_e;

public class Abstraction_2 extends Abstraction {
	void show() {
		System.out.println("1");
	}

}
