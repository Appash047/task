package interfac_e;

public interface Interface2 {

	void display();
}
