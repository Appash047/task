package interfac_e;

public interface Interface1 {

	void show();
}
