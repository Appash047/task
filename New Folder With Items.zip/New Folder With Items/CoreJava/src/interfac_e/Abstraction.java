package interfac_e;

public abstract class Abstraction {
	
	abstract void show() ;

	

		
	}


