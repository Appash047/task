package wrapperClass;

import java.io.FileInputStream;

public class Demo {
	public static void main(String[] args) {
		
		
	}

}
