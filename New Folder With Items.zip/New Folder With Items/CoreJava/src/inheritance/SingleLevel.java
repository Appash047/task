package inheritance;

public class SingleLevel {
	
	 void showA()
	{
		System.out.println("this is class A");
	}


}
