package inheritance;

public class MultiLevelB extends MultiLevelA{
	 void showB()
		{
			System.out.println("this is class B");
		}

}
