package inheritance;

public class HierarchicalC extends HierarchicalA{
	 void showC()
		{
			System.out.println("this is class C");
		}

	public static void main(String[] args) {
		HierarchicalA oba=new HierarchicalA();
		oba.showA();
		//oba.showB();
	
		System.out.println("...........................");
		
		HierarchicalB obb=new HierarchicalB();
		obb.showA();
		obb.showB();
		
		System.out.println("...........................");
		
		HierarchicalC obc=new HierarchicalC();
		obc.showA();
//		obc.showB();
		obc.showC();
	}

}
