package inheritance;

public class MultiLevelC extends MultiLevelB {
	
	 void showC()
		{
			System.out.println("this is class C");
		}

	public static void main(String[] args) {
		
		MultiLevelA oba=new MultiLevelA();
		oba.showA();
		//oba.showB();
	
		System.out.println("...........................");
		
		MultiLevelB obb=new MultiLevelB();
		obb.showA();
		obb.showB();
		
		System.out.println("...........................");
		
		MultiLevelC obc=new MultiLevelC();
		obc.showA();
		obc.showB();
		obc.showC();


	}

}
