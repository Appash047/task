package inheritance;

public class HierarchicalB extends HierarchicalA {
	 void showB()
		{
			System.out.println("this is class B");
		}

}
