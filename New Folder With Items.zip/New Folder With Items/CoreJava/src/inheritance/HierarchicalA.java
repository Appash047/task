package inheritance;

public class HierarchicalA {
	 void showA()
		{
			System.out.println("this is class A");
		}

}
