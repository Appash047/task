package inheritance;

public class MultiLevelA {
	 void showA()
		{
			System.out.println("this is class A");
		}


}
