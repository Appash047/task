package inheritance;

public class SingleLevel1 extends SingleLevel{
	 void showB()
		{
			System.out.println("this is class B");
		}
	

	public static void main(String[] args) {
		
		SingleLevel1 s1=new SingleLevel1();
		s1.showA();
		s1.showB();
		
		
		SingleLevel s2=new SingleLevel();
		s2.showA();
//		s2.showB();    the s2 is a parent class object
		
	}

}
