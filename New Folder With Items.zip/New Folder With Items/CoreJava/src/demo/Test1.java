package demo;

public class Test1 {
	static String test(String s1,String s2) {
		
		String newString = "";

		for (int i = 0; i < s1.length(); i++) {
		    for (int j = 0; j < s2.length(); j++) {
		        if (s1.charAt(i) == s2.charAt(j)) {
		            newString += s1.charAt(i);
		            break;
		        }
		    }
		}
		System.out.println("The same characters in both strings are: " + newString);
		return newString;

	}

	public static void main(String[] args) {

		test("mallesh", "appash");
		
		
		
	}

}
