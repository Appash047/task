package demo;

import java.util.Scanner;

public class Demo {
	 public static void main(String args[]) {
	        Scanner sc = new Scanner(System.in);
	        int x = sc.nextInt();
	        int n = sc.nextInt();

	        int ans = modularExponentiation(x, n);
	        System.out.println(ans);
	    }

	    // TODO: Implement this method
	    static int modularExponentiation(int x, int n) {
	        int M = 1000000007;
	        long a = (long) Math.pow(x, n);

	        long b = a%M;

	        return (int)b;
	    }
	}


