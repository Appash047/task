package demo;

public class Demo1 {

	public static void main(String[] args) {

		System.out.println("helloooo\n");
		System.out.println("helloooo\t");
		System.out.println("helloooo\r");
		System.out.println("helloooo\b");
		System.out.println("helloooo\f");
		System.out.println("helloooo");
		System.out.println("helloooo");


	}

}
