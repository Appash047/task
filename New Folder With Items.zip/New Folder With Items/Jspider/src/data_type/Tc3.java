package data_type;

public class Tc3 {

	public static void main(String[] args) {
	
		
		
		//byte to int
		
		byte a=65;
		int b=a;// implicit conversion
		
		System.out.println(a);
		System.out.println(b);
		
		/*
		 * output: 65
		 *         65
		 */


	}

}
