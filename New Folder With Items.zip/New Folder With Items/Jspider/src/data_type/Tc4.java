package data_type;

public class Tc4 {

	public static void main(String[] args) {

		
		// byte to long
		
				byte a=65;
				long b=a;// implicit conversion
				
				System.out.println(a);
				System.out.println(b);
				
				/*
				 * output: 65
				 *         65
				 */


	}

}
