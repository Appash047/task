package data_type;

public class Tc13 {

	public static void main(String[] args) {
		
		
	// char to double
		
		char a='p';
		double b=a;// implicit conversion
		
		System.out.println(a);
		System.out.println(b);
		
		/*
		 * output:  p
		 *          112
		 */

	}

}
