package data_type;

public class Tc31 {

	public static void main(String[] args) {
		
		
		// long to int
		
					long a=65;
					int b=a;// implicit conversion
					
					System.out.println(a);
					System.out.println(b);
					
					/*
					 * output:  Unresolved compilation problem: 
			Type mismatch: cannot convert from long to int

					 */

	}

}
