package data_type;

public class Tc21 {

	public static void main(String[] args) {
		
		

		// int to byte
			
			int a=65;
			byte b=a;// implicit conversion
			
			System.out.println(a);
			System.out.println(b);
			
			/*
			 * output:  Unresolved compilation problem: 
	Type mismatch: cannot convert from int to byte

			 */

	}

}
