package data_type;

public class Tc6 {

	public static void main(String[] args) {
		
		// byte to double
		
				byte a=65;
				double b=a;// implicit conversion
				
				System.out.println(a);
				System.out.println(b);
				
				/*
				 * output: 65
				 *         65.0
				 */


	}

}
