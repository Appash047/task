package data_type;

public class Tc38 {

	public static void main(String[] args) {
		
		
		// float to int
		
		float a=65.4f;
		int b=a;// implicit conversion
		
		System.out.println(a);
		System.out.println(b);
		
		/*
		 * output:  Unresolved compilation problem: 
             Type mismatch: cannot convert from float to int

    	 */

	}

}
