package data_type;

public class Tc14 {

	public static void main(String[] args) {
		

	// short to byte
		
		short a=65;
		byte b=a;// implicit conversion
		
		System.out.println(a);
		System.out.println(b);
		
		/*
		 * output:  Unresolved compilation problem: 
Type mismatch: cannot convert from char to byte
		 */

	}

}
