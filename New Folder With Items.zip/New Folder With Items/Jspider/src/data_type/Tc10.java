package data_type;

public class Tc10 {

	public static void main(String[] args) {
	
		
		// char to int
		
		char a='p';
		int b=a;// implicit conversion
		
		System.out.println(a);
		System.out.println(b);
		
		/*
		 * output: p
		 *         112
		 */

	}

}
