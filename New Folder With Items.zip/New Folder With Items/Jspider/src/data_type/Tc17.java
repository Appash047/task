package data_type;

public class Tc17 {

	public static void main(String[] args) {
		
		

		// short to int
			
			short a=65;
			int b=a;// implicit conversion
			
			System.out.println(a);
			System.out.println(b);
			
			/*
			 * output:65
			 *        65
			 */


	}

}
