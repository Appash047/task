package data_type;

public class Tc48 {

	public static void main(String[] args) {
		
		
		// double to double
		
				double a=65.4;
				double b=a;// implicit conversion
				
				System.out.println(a);
				System.out.println(b);
				
				/*
				 * output:  65.4
				 *          65.4
		 */
	}

}
