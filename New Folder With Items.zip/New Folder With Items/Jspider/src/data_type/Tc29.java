package data_type;

public class Tc29 {

	public static void main(String[] args) {
		
		
		// long to char
		
					long a=65;
					char b=a;// implicit conversion
					
					System.out.println(a);
					System.out.println(b);
					
					/*
					 * output:  Unresolved compilation problem: 
			Type mismatch: cannot convert from long to char

					 */

	}

}
