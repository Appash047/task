package data_type;

public class Tc45 {

	public static void main(String[] args) {
		

		// double to int
		
				double a=65.4;
				int b=a;// implicit conversion
				
				System.out.println(a);
				System.out.println(b);
				
				/*
				 * output:   Unresolved compilation problem: 
			       Type mismatch: cannot convert from double to int
		 */
	}

}
