package data_type;

public class TC47 {

	public static void main(String[] args) {
		
		
		// double to float
		
				double a=65.4;
				float b=a;// implicit conversion
				
				System.out.println(a);
				System.out.println(b);
				
				/*
				 * output:   Unresolved compilation problem: 
			       Type mismatch: cannot convert from double to float
		 */
	}

}
