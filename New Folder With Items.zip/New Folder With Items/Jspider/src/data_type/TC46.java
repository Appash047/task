package data_type;

public class TC46 {

	public static void main(String[] args) {
		// double to long
		
				double a=65.4;
				long b=a;// implicit conversion
				
				System.out.println(a);
				System.out.println(b);
				
				/*
				 * output:   Unresolved compilation problem: 
			       Type mismatch: cannot convert from double to long
		 */
	}

}
