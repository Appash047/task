package data_type;

public class Tc12 {

	public static void main(String[] args) {
		

	// char to float
		
		char a='p';
		float b=a;// implicit conversion
		
		System.out.println(a);
		System.out.println(b);
		
		/*
		 * output:  p
		 *          112.0
		 */

	}

}
