package data_type;

public class Tc41 {

	public static void main(String[] args) {
		
		
		// float to double
		
		float a=65.4f;
		double b=a;// implicit conversion
		
		System.out.println(a);
		System.out.println(b);
		
		/*
		 * output:  65.4
		 *          65.400001525789
    	 */


	}

}
