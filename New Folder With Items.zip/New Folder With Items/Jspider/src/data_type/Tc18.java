package data_type;

public class Tc18 {

	public static void main(String[] args) {
		
		

		// short to long
			
			short a=65;
			long b=a;// implicit conversion
			
			System.out.println(a);
			System.out.println(b);
			
			/*
			 * output: 65
			 *         65
			 */

	}

}
