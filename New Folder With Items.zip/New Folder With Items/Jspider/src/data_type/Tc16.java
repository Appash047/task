package data_type;

public class Tc16 {

	public static void main(String[] args) {
		
		

		// short to short
			
			short a=65;
			short b=a;// implicit conversion
			
			System.out.println(a);
			System.out.println(b);
			
			/*
			 * output: 65
			 *         65
			 *         */


	}

}
