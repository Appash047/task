package data_type;

public class Tc1 {

	public static void main(String[] args) {
		
	
		
		//byte to char
		
		byte a=65;
		char b=a;// implicit conversion
		
		System.out.println(a);
		System.out.println(b);
		
		/* output:
		 * Unresolved compilation problem: 
	Type mismatch: cannot convert from byte to char

		 */
	}

}
