package data_type;

public class Tc33 {

	public static void main(String[] args) {
		
		
		// long to float
		
					long a=65;
					float b=a;// implicit conversion
					
					System.out.println(a);
					System.out.println(b);
					
					/*
					 * output:  65
					 *          65.0

					 */

	}

}
