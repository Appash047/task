package data_type;

public class Tc9 {

	public static void main(String[] args) {
	
	// char to short
		
		char a='p';
		short b=a;// implicit conversion
		
		System.out.println(a);
		System.out.println(b);
		
		/*
		 * output:  Unresolved compilation problem: 
Type mismatch: cannot convert from char to byte
		 */

	}

}
