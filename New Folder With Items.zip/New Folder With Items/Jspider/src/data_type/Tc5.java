package data_type;

public class Tc5 {

	public static void main(String[] args) {
		
		
		// byte to float
		
				byte a=65;
				float b=a;// implicit conversion
				
				System.out.println(a);
				System.out.println(b);
				
				/*
				 * output: 65
				 *         65.0
				 */


	}

}
