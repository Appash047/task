package data_type;

public class Tc1_1 {

	public static void main(String[] args) {
		
		
		// byte to byte
		
		byte a=65;
		byte b=a;// implicit conversion
		
		System.out.println(a);
		System.out.println(b);
		
		/*
		 * output: 65
		 *         65
		 */



	}

}
