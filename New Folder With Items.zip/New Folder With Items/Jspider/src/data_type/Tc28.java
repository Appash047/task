package data_type;

public class Tc28 {

	public static void main(String[] args) {
		
		

		// long to byte
			
			long a=65;
			byte b=a;// implicit conversion
			
			System.out.println(a);
			System.out.println(b);
			
			/*
			 * output:  Unresolved compilation problem: 
	Type mismatch: cannot convert from long to byte

			 */

	}

}
