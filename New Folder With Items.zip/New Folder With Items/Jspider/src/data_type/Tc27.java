package data_type;

public class Tc27 {

	public static void main(String[] args) {
		
		

		// int to double
			
			int a=65;
			double b=a;// implicit conversion
			
			System.out.println(a);
			System.out.println(b);
			
			/*
			 * output:  65
			 *          65.0

			 */


	}

}
