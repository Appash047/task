package com.jsp.Springbootcrud.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.Springbootcrud.Service.EmployeeService;
import com.jsp.Springbootcrud.dto.Employee;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;

	@PostMapping("/save")
	public Employee save(@RequestBody Employee employee) {
		return employeeService.save(employee);
	}

	@GetMapping("/display")
	public List<Employee> display() {
		return employeeService.display();
	}

	@GetMapping("/find/{id}")
	public Employee find(@PathVariable int id) {
		return employeeService.find(id);
	}
}
