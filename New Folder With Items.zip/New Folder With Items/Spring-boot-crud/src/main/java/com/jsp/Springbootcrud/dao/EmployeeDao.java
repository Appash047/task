package com.jsp.Springbootcrud.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.Springbootcrud.Repository.EmployeeRepository;
import com.jsp.Springbootcrud.dto.Employee;

@Repository
public class EmployeeDao {

	@Autowired
	EmployeeRepository employeeRepository;

	public Employee save(Employee employee) {
		return employeeRepository.save(employee);
	}

	public List<Employee> display() {
		return employeeRepository.findAll();
	}

	public Employee find(int id) {
		Optional<Employee> optional = employeeRepository.findById(id);
		return optional.get();
	}

	public Employee update(Employee employee) {
		Optional<Employee> optional = employeeRepository.findById(employee.getId());
		if (optional.get() != null) {
			employeeRepository.save(optional.get());
			return employee;
		}
		return null;
	}

	public String delete(int id) {
		Optional<Employee> optional = employeeRepository.findById(id);
		if (optional.get() != null) {
			employeeRepository.delete(optional.get());
			return "Data deleted";
		}
		return null;
	}

}
