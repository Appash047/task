package com.jsp.Springbootcrud.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jsp.Springbootcrud.dao.EmployeeDao;
import com.jsp.Springbootcrud.dto.Employee;

@Service
public class EmployeeService {

	@Autowired
	EmployeeDao employeeDao;

	public Employee save(Employee employee) {
		return employeeDao.save(employee);
	}

	public List<Employee> display() {
		return employeeDao.display();
	}

	public Employee find(int id) {
		return employeeDao.find(id);
	}
	
	
}
