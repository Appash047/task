package com.jsp.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jsp.Dao.StudentDao;
import com.jsp.Dto.Student;

@Service
public class StudentService {

	@Autowired
	StudentDao studentDao;

	public Student save(Student student) {
		return studentDao.save(student);
	}

	public Student update(Student student) {
		return studentDao.update(student);
	}
}
